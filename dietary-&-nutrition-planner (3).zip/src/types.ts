/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'Dietitian' | 'Doctor' | 'KitchenStaff' | 'Admin' | 'Patient';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  avatarUrl?: string;
  department?: string;
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female';
  weight: number; // in kg
  height: number; // in cm
  activityLevel: 'Sedentary' | 'Light' | 'Moderate' | 'Active';
  medicalConditions: string[]; // e.g. Diabetes, Hypertension, Celiac Disease, renal
  allergies: string[]; // e.g. Peanuts, Dairy, Gluten, Egg, Shellfish
  roomNumber: string;
  ward: string;
  admissionDate: string;
  targetCalories: number; // Calculated daily caloric need
  macronutrients: {
    protein: number; // in grams
    carbs: number;   // in grams
    fat: number;     // in grams
  };
}

export interface MealDetail {
  title: string;
  ingredients: string[];
  calories: number;
  protein: number; // grams
  carbs: number;   // grams
  fat: number;     // grams
  allergens: string[];
}

export interface MealPlan {
  id: string;
  patientId: string;
  patientName: string;
  breakfast: MealDetail;
  lunch: MealDetail;
  dinner: MealDetail;
  snacks: MealDetail;
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  status: 'Pending' | 'Approved' | 'Rejected';
  approvedBy?: string;
  approvedDate?: string;
  dietitianNotes: string;
  suitabilityRationale: string; // generated explanation of why this matches their condition
  allergyCheckPassed: boolean;
  flaggedAllergens: string[]; // any overlap detected
  createdAt: string;
}

export interface KitchenOrder {
  id: string;
  mealPlanId: string;
  patientId: string;
  patientName: string;
  roomNumber: string;
  ward: string;
  mealDate: string; // YYYY-MM-DD
  mealTime: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  mealTitle: string;
  ingredients: string[];
  allergens: string[];
  specialInstructions: string;
  status: 'Received' | 'Preparing' | 'Ready' | 'Delivered' | 'Cancelled';
  assignedStaff?: string;
  updatedAt: string;
}

export interface NotificationAlert {
  id: string;
  title: string;
  message: string;
  type: 'allergy' | 'update' | 'approval' | 'info';
  patientId?: string;
  createdAt: string;
  read: boolean;
}

export interface DiagnosticMetrics {
  totalPatients: number;
  pendingApprovals: number;
  activeDietsCount: number;
  mealsInPreparation: number;
  allergyTriggersPrevented: number;
}
