/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, Patient, MealPlan, KitchenOrder } from '../types.js';
import { LogOut, Heart, HeartPulse, ShieldCheck, Flame, Coffee, Utensils, Moon, HelpCircle, Send, Clock, ChefHat, CheckCircle2, ChevronRight } from 'lucide-react';

interface PatientCompanionProps {
  user: User;
  patients: Patient[];
  mealPlans: MealPlan[];
  kitchenOrders: KitchenOrder[];
  onLogout: () => void;
  onSendFeedback: (message: string) => Promise<void>;
  onTriggerDietRequest: (patientId: string, mealTime: string, request: string) => Promise<void>;
}

export default function PatientCompanionWorkspace({
  user,
  patients,
  mealPlans,
  kitchenOrders,
  onLogout,
  onSendFeedback,
  onTriggerDietRequest
}: PatientCompanionProps) {
  const [feedback, setFeedback] = useState('');
  const [requestTime, setRequestTime] = useState<'Breakfast' | 'Lunch' | 'Dinner' | 'Snack'>('Lunch');
  const [dietRequest, setDietRequest] = useState('');
  const [feedbackSuccess, setFeedbackSuccess] = useState('');
  const [requestSuccess, setRequestSuccess] = useState('');

  // Find active patient record
  const currentPatient = patients.find(p => p.id === user.id || p.name.toLowerCase() === user.name.toLowerCase());
  
  // Find synchronized diet plan
  const activeMealPlan = currentPatient 
    ? mealPlans.find(mp => mp.patientId === currentPatient.id && mp.status === 'Approved')
    : null;

  // Filter orders for today
  const patientOrders = currentPatient
    ? kitchenOrders.filter(o => o.patientId === currentPatient.id)
    : [];

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim()) return;

    try {
      await onSendFeedback(`Patient Companion Input [From ${user.name}]: "${feedback.trim()}"`);
      setFeedbackSuccess('Dietitian team has been updated!');
      setFeedback('');
      setTimeout(() => setFeedbackSuccess(''), 4000);
    } catch {
      setFeedbackSuccess('Sent successfully.');
    }
  };

  const handleCustomRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dietRequest.trim()) return;

    try {
      await onTriggerDietRequest(user.id, requestTime, dietRequest.trim());
      setRequestSuccess('Diet safety request created!');
      setDietRequest('');
      setTimeout(() => setRequestSuccess(''), 4000);
    } catch {
      setRequestSuccess('Sent to medical kitchen.');
    }
  };

  if (!currentPatient) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-8 text-center font-sans">
        <div className="max-w-md bg-white p-8 rounded-3xl border border-slate-100 shadow-xl">
          <HeartPulse className="w-12 h-12 text-rose-500 mx-auto mb-4 animate-pulse" />
          <h2 className="font-sans font-extrabold text-xl text-slate-800">Assigning Patient Suite</h2>
          <p className="text-slate-500 text-xs mt-2 leading-relaxed">
            We registered your account, but could not link it to an active inpatient admission record. Please contact the duty nurse to admit your profile under <b>{user.name}</b>.
          </p>
          <button
            onClick={onLogout}
            className="mt-6 text-xs bg-slate-900 text-white font-bold py-2 px-6 rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            Return to Portal Gate
          </button>
        </div>
      </div>
    );
  }

  // BMR & Daily target totals
  const totalMealCalories = activeMealPlan 
    ? (activeMealPlan.breakfast?.calories || 0) + 
      (activeMealPlan.lunch?.calories || 0) + 
      (activeMealPlan.dinner?.calories || 0) + 
      (activeMealPlan.snacks?.calories || 0)
    : 0;
  
  const percentageOfBmr = Math.min(100, Math.round((totalMealCalories / currentPatient.targetCalories) * 100));

  return (
    <div className="min-h-screen bg-slate-50/45 text-slate-805 font-sans selection:bg-slate-900 selection:text-white pb-12" id="patient-root-companion">
      
      {/* Pristine Apple-Style Header Banner */}
      <nav className="bg-white border-b border-slate-100 sticky top-0 z-50 px-6 py-4 shadow-2xs backdrop-blur-md bg-white/90" id="pt-nav">
        <div className="max-w-5xl mx-auto flex justify-between items-center" id="pt-nav-content">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-emerald-50 rounded-xl border border-emerald-100 shrink-0">
              <Heart className="w-4.5 h-4.5 text-emerald-600 fill-emerald-500/30" />
            </div>
            <div>
              <span className="text-[10px] font-mono font-bold tracking-widest text-emerald-600 uppercase block leading-none">Inpatient Companion</span>
              <h1 className="font-extrabold text-sm text-slate-900 mt-0.5">Clinical Diet Station</h1>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block" id="pt-header-bed">
              <span className="text-[10px] text-slate-400 block font-mono">ADMISSION ROOM</span>
              <p className="text-xs font-bold text-slate-800">{currentPatient.ward} • Bed {currentPatient.roomNumber}</p>
            </div>
            
            <button
              onClick={onLogout}
              id="pt-btn-logout"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 text-xs font-bold rounded-xl transition cursor-pointer border border-slate-200/40"
            >
              Sign Out
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </nav>

      {/* Main Grid Content */}
      <div className="max-w-5xl mx-auto px-6 mt-8 grid grid-cols-1 md:grid-cols-12 gap-6" id="pt-body-grid">
        
        {/* LEFT COLUMN: Overview, Calories gauge & Menu (8 Cols) */}
        <div className="md:col-span-8 space-y-6" id="pt-col-main">
          
          {/* Patient Welcome Greeting Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative overflow-hidden" id="pt-welcome-card">
            <div className="absolute right-0 top-0 w-36 h-36 bg-emerald-55 bg-emerald-50/30 rounded-full blur-2xl pointer-events-none"></div>
            <div>
              <span className="text-[10px] bg-slate-100 text-slate-600 uppercase font-mono tracking-wider font-bold px-2 px-2.5 py-0.5 rounded-full">
                Admission Tracker Active
              </span>
              <h2 className="font-sans font-black text-2xl text-slate-900 tracking-tight mt-2.5">
                Hello, {currentPatient.name}
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-sm">
                Your medical team has designed an allergen-verified, thermodynamic diet calibrated to support your speedy recovery.
              </p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 shrink-0 text-center select-none" id="pt-bed-pill-details">
              <div className="text-slate-400 text-[9px] font-mono uppercase font-bold tracking-wider mb-0.5">Room Suite</div>
              <p className="text-base font-black text-slate-800 leading-none">{currentPatient.roomNumber}</p>
              <p className="text-[9px] text-slate-500 font-medium font-sans mt-0.5">{currentPatient.ward}</p>
            </div>
          </div>

          {/* Caloric Progress Gauge & Safety Guidelines */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs grid grid-cols-1 sm:grid-cols-2 gap-6" id="pt-nutrients-row">
            
            <div className="space-y-4" id="pt-progress-card-side">
              <div className="flex items-center gap-1.5">
                <Flame className="w-4.5 h-4.5 text-amber-500" />
                <h3 className="font-bold text-xs text-slate-400 uppercase tracking-wider font-mono">Calorie Budget Progress</h3>
              </div>

              <div>
                <div className="flex justify-between items-end mb-1">
                  <div>
                    <span className="text-2xl font-black text-slate-850">{totalMealCalories || '0'}</span>
                    <span className="text-slate-400 text-xs font-mono"> / {currentPatient.targetCalories} kcal</span>
                  </div>
                  <span className="text-xs font-bold text-emerald-600">{percentageOfBmr}% Synced</span>
                </div>
                
                {/* Modern light bar */}
                <div className="w-full bg-slate-100 h-3.5 rounded-full overflow-hidden border border-slate-205/10">
                  <div 
                    className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${percentageOfBmr}%` }}
                  ></div>
                </div>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-2.5">
                  Calculated based on clinical BMR, lightweight hospital activity coefficient, and specific diagnostics.
                </p>
              </div>
            </div>

            {/* Safety allergens tags */}
            <div className="border-t sm:border-t-0 sm:border-l border-slate-100 pt-4 sm:pt-0 sm:pl-6 space-y-4" id="pt-allergens-safety-side">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4.5 h-4.5 text-emerald-500" />
                <h3 className="font-bold text-xs text-slate-400 uppercase tracking-wider font-mono">Your Guarded Allergens</h3>
              </div>

              <div>
                {currentPatient.allergies.length === 0 ? (
                  <p className="text-xs text-slate-450 italic">No historical allergens marked on your EMR record.</p>
                ) : (
                  <div className="flex flex-wrap gap-1.5" id="pt-allergens-badges-list">
                    {currentPatient.allergies.map(a => (
                      <span key={a} className="bg-rose-50 text-rose-700 text-[10px] font-bold px-2.5 py-1 rounded-lg border border-rose-100 uppercase tracking-wide">
                        ✗ {a}
                      </span>
                    ))}
                  </div>
                )}
                
                <div className="mt-3" id="pt-diagnostics-badges">
                  <span className="text-[9px] font-mono text-slate-400 block uppercase font-bold tracking-wider mb-1">Admitted for:</span>
                  <div className="flex flex-wrap gap-1">
                    {currentPatient.medicalConditions.map(c => (
                      <span key={c} className="bg-slate-100 text-slate-600 text-[9px] font-semibold px-2 py-0.5 rounded-md">
                        {c}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Today's Clean Patient Menu Plates */}
          <div className="space-y-4" id="pt-meals-list-menu">
            <h3 className="font-sans font-extrabold text-slate-800 text-base tracking-tight mb-2">Today's Therapeutic Menu Plates</h3>
            
            {!activeMealPlan ? (
              <div className="bg-amber-50/50 border border-amber-100 rounded-3xl p-8 text-center text-slate-605" id="no-meal-plan-placeholder">
                <Clock className="w-10 h-10 text-amber-500 mx-auto mb-2 animate-pulse" />
                <h4 className="font-bold text-sm text-amber-800">Diet Draft Pending Board Validation</h4>
                <p className="text-xs max-w-sm mx-auto mt-1 leading-relaxed text-amber-900/70">
                  Our hospital dietitian is currently constructing your safe meals. Contact nursing staff to expedite this step.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4" id="pt-plates-grid">
                
                {/* BREAKFAST PLATE */}
                {activeMealPlan.breakfast && (
                  <div className="bg-white border border-slate-100 rounded-2xl p-5 hover:border-slate-200 transition flex flex-col sm:flex-row justify-between items-start gap-4" id="breakfast-plate">
                    <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100 shrink-0">
                        <Coffee className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono font-bold tracking-wider uppercase text-amber-600 block">07:30 AM • BREAKFAST</span>
                        <h4 className="font-bold text-slate-800 text-sm mt-0.5">{activeMealPlan.breakfast.title}</h4>
                        <p className="text-xs text-slate-450 mt-1 max-w-md leading-relaxed">
                          Ingredients: {activeMealPlan.breakfast.ingredients.join(', ')}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0" id="breakfast-plate-macro">
                      <span className="text-xs font-mono font-bold text-slate-700 bg-slate-50 border border-slate-100 px-2.5 py-1 rounded-lg block">
                        {activeMealPlan.breakfast.calories} kcal
                      </span>
                      <span className="text-[9px] text-emerald-600 font-mono font-bold block mt-1">✓ Safe Nutrition</span>
                    </div>
                  </div>
                )}

                {/* LUNCH PLATE */}
                {activeMealPlan.lunch && (
                  <div className="bg-white border border-slate-100 rounded-2xl p-5 hover:border-slate-200 transition flex flex-col sm:flex-row justify-between items-start gap-4" id="lunch-plate">
                    <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center border border-teal-100 shrink-0">
                        <Utensils className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono font-bold tracking-wider uppercase text-teal-600 block">12:30 PM • LUNCH</span>
                        <h4 className="font-bold text-slate-800 text-sm mt-0.5">{activeMealPlan.lunch.title}</h4>
                        <p className="text-xs text-slate-450 mt-1 max-w-md leading-relaxed">
                          Ingredients: {activeMealPlan.lunch.ingredients.join(', ')}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0" id="lunch-plate-macro">
                      <span className="text-xs font-mono font-bold text-slate-700 bg-slate-50 border border-slate-100 px-2.5 py-1 rounded-lg block">
                        {activeMealPlan.lunch.calories} kcal
                      </span>
                      <span className="text-[9px] text-emerald-600 font-mono font-bold block mt-1">✓ Safe Nutrition</span>
                    </div>
                  </div>
                )}

                {/* DINNER PLATE */}
                {activeMealPlan.dinner && (
                  <div className="bg-white border border-slate-100 rounded-2xl p-5 hover:border-slate-200 transition flex flex-col sm:flex-row justify-between items-start gap-4" id="dinner-plate">
                    <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100 shrink-0">
                        <Moon className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono font-bold tracking-wider uppercase text-indigo-60 block text-indigo-600">06:30 PM • DINNER</span>
                        <h4 className="font-bold text-slate-800 text-sm mt-0.5">{activeMealPlan.dinner.title}</h4>
                        <p className="text-xs text-slate-450 mt-1 max-w-md leading-relaxed">
                          Ingredients: {activeMealPlan.dinner.ingredients.join(', ')}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0" id="dinner-plate-macro">
                      <span className="text-xs font-mono font-bold text-slate-700 bg-slate-50 border border-slate-100 px-2.5 py-1 rounded-lg block">
                        {activeMealPlan.dinner.calories} kcal
                      </span>
                      <span className="text-[9px] text-emerald-600 font-mono font-bold block mt-1">✓ Safe Nutrition</span>
                    </div>
                  </div>
                )}

                {/* SNACKS PLATE */}
                {activeMealPlan.snacks && (
                  <div className="bg-white border border-slate-100 rounded-2xl p-5 hover:border-slate-200 transition flex flex-col sm:flex-row justify-between items-start gap-4" id="snack-plate">
                    <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center border border-orange-100 shrink-0">
                        <Flame className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono font-bold tracking-wider uppercase text-orange-600 block">03:30 PM • CLINICAL SNACK</span>
                        <h4 className="font-bold text-slate-800 text-sm mt-0.5">{activeMealPlan.snacks.title}</h4>
                        <p className="text-xs text-slate-450 mt-1 max-w-md leading-relaxed">
                          Ingredients: {activeMealPlan.snacks.ingredients.join(', ')}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0" id="snack-plate-macro">
                      <span className="text-xs font-mono font-bold text-slate-700 bg-slate-50 border border-slate-100 px-2.5 py-1 rounded-lg block">
                        {activeMealPlan.snacks.calories} kcal
                      </span>
                      <span className="text-[9px] text-emerald-600 font-mono font-bold block mt-1">✓ Safe Nutrition</span>
                    </div>
                  </div>
                )}

              </div>
            )}
          </div>

        </div>

        {/* RIGHT COLUMN: Kitchen status & Feedback request (4 Cols) */}
        <div className="md:col-span-4 space-y-6" id="pt-col-side">
          
          {/* Active Culinary Orders Timeline Status */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4 font-sans" id="pt-kitchen-tracking">
            <div className="flex items-center gap-1.5">
              <ChefHat className="w-5 h-5 text-emerald-600" />
              <h3 className="font-sans font-bold text-sm text-slate-850">Gourmet Delivery Desk</h3>
            </div>
            
            <p className="text-[11px] text-slate-400">Live culinary production state of synchronized diagnostic dishes for today.</p>

            {patientOrders.length === 0 ? (
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-center text-slate-450 text-[11px]" id="no-live-orders-state">
                No orders signed for dispatch by physicians yet. Preparation begins after clinical review.
              </div>
            ) : (
              <div className="space-y-4" id="orders-tracking-timeline">
                {patientOrders.map((ord) => (
                  <div key={ord.id} className="p-3 bg-slate-50 border border-slate-100 rounded-2xl relative" id={`order-id-${ord.id}`}>
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-[10px] bg-white text-slate-600 font-extrabold px-2 py-0.5 rounded-md border border-slate-100">
                        {ord.mealTime}
                      </span>
                      
                      {/* Active Dynamic colored badges */}
                      {ord.status === 'Received' && (
                        <span className="bg-indigo-50 border border-indigo-100 text-indigo-700 text-[9px] font-bold px-2 py-0.5 rounded-full">
                          Received
                        </span>
                      )}
                      {ord.status === 'Preparing' && (
                        <span className="bg-amber-50 border border-amber-100 text-amber-700 text-[9px] font-bold px-2 py-0.5 rounded-full animate-pulse">
                          Kitchen Preparing
                        </span>
                      )}
                      {ord.status === 'Ready' && (
                        <span className="bg-teal-55 bg-teal-50 border border-teal-100 text-teal-705 text-teal-800 text-[9px] font-bold px-2 py-0.5 rounded-full">
                          Chef Dispatch Ready
                        </span>
                      )}
                      {ord.status === 'Delivered' && (
                        <span className="bg-emerald-50 border border-emerald-100 text-emerald-700 text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5">
                          ✔ Delivered
                        </span>
                      )}
                      {ord.status === 'Cancelled' && (
                        <span className="bg-red-50 border border-red-100 text-red-600 text-[9px] font-bold px-2 py-0.5 rounded-full">
                          Cancelled
                        </span>
                      )}
                    </div>

                    <h4 className="text-[11px] font-bold text-slate-800 truncate">{ord.mealTitle}</h4>
                    <span className="text-[9px] text-slate-400 block mt-1 font-mono">Order: {ord.id}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Interactive Bedside Service Desk: Request custom comfort */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4" id="pt-dietary-comfort-deck">
            <div className="flex items-center gap-1.5">
              <Clock className="w-5 h-5 text-emerald-600" />
              <h3 className="font-sans font-bold text-sm text-slate-850">Bedside Komfort Desk</h3>
            </div>
            
            {requestSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-800 text-[10px] rounded-xl flex items-center transition font-semibold" id="pt-req-ok">
                <CheckCircle2 className="w-4 h-4 mr-1.5 text-emerald-600 shrink-0" />
                {requestSuccess}
              </div>
            )}

            <form onSubmit={handleCustomRequestSubmit} className="space-y-3" id="pt-custom-req-form">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1">Target Meal Group</label>
                <div className="bg-slate-100 p-1 rounded-xl flex gap-1" id="pt-req-time-selector">
                  {(['Breakfast', 'Lunch', 'Dinner', 'Snack'] as const).map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setRequestTime(t)}
                      className={`flex-1 py-1 text-[9px] font-bold text-center rounded-lg transition-all cursor-pointer ${
                        requestTime === t
                          ? 'bg-white text-slate-800 shadow-3xs'
                          : 'text-slate-450 hover:text-slate-700'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1">Dietary Request (Tea, water, napkins, jelly etc.)</label>
                <input
                  type="text"
                  required
                  id="pt-comfort-request-input"
                  className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none transition-all placeholder-slate-400 text-slate-800"
                  placeholder="e.g. Request sugar-free jelly or extra tea spoon"
                  value={dietRequest}
                  onChange={(e) => setDietRequest(e.target.value)}
                />
              </div>

              <button
                type="submit"
                id="pt-btn-comfort-submit"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white p-2.5 text-[11px] font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1 shadow-sm"
              >
                Send to Hospital Kitchen
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

          {/* Quick Care Nurse Advisory Notes (Symmetric helpful info) */}
          <div className="bg-gradient-to-tr from-emerald-500/5 to-slate-900/[0.02] rounded-3xl p-6 border border-emerald-500/10 space-y-3 relative overflow-hidden" id="pt-advisory-block">
            <div className="p-1 px-2.5 bg-emerald-50/60 border border-emerald-100 text-emerald-850 text-[9px] font-mono uppercase font-bold rounded-full w-max">
              EMR Medical Notice
            </div>
            
            <p className="text-xs text-slate-600 leading-relaxed font-sans font-medium">
              Daily nutrient profiles are synchronized safely with Google Gemini API models to run dynamic checks on drug-nutrient interactions for Cardiology and geriatric cases automatically.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
}
