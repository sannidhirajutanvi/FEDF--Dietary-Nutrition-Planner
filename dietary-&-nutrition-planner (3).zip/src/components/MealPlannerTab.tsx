/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Patient, MealPlan, User } from '../types.js';
import { Sparkles, Check, AlertTriangle, ScrollText, Play, Coffee, Utensils, Moon, HelpCircle, ChefHat, Info, Stethoscope, AlertOctagon } from 'lucide-react';

interface MealPlannerProps {
  patients: Patient[];
  mealPlans: MealPlan[];
  onGeneratePlan: (patient: Patient) => Promise<MealPlan>;
  onSavePlan: (plan: MealPlan) => Promise<void>;
  onUpdatePlanStatus: (planId: string, status: 'Approved' | 'Rejected', doctorName: string) => Promise<void>;
  currentUser: User;
}

export default function MealPlannerTab({ patients, mealPlans, onGeneratePlan, onSavePlan, onUpdatePlanStatus, currentUser }: MealPlannerProps) {
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [tempPlan, setTempPlan] = useState<MealPlan | null>(null);
  const [dietitianNotesInput, setDietitianNotesInput] = useState('');

  // Find active patient details
  const activePatient = patients.find(p => p.id === selectedPatientId);

  const triggerAIGeneration = async () => {
    if (!activePatient) return;
    setIsGenerating(true);
    setTempPlan(null);
    setDietitianNotesInput('');

    // Simulated medical checklists during loading state
    const steps = [
      'Reading patient record and vitals...',
      'Mapping daily calorie limits to BMR Bendix formulas...',
      'Formulating clinical diet constraints (low-sodium/high-fiber)...',
      'Deploying Gemini clinical dietitian filters...',
      'Performing allergy tolerance tests on potential recipes...',
      'Synthesizing clinical rationales and dietary plans...'
    ];

    let stepIndex = 0;
    setLoadingStep(steps[stepIndex]);
    const interval = setInterval(() => {
      stepIndex++;
      if (stepIndex < steps.length) {
        setLoadingStep(steps[stepIndex]);
      }
    }, 1200);

    try {
      const generated = await onGeneratePlan(activePatient);
      // Ensure local comments default
      generated.dietitianNotes = dietitianNotesInput;
      setTempPlan(generated);
    } catch (e) {
      console.error(e);
    } finally {
      clearInterval(interval);
      setIsGenerating(false);
    }
  };

  const handleSaveAndSubmit = async () => {
    if (!tempPlan) return;
    const finalPlan = {
      ...tempPlan,
      dietitianNotes: dietitianNotesInput || tempPlan.dietitianNotes,
      status: 'Pending' as const
    };
    await onSavePlan(finalPlan);
    setTempPlan(null);
    setSelectedPatientId('');
  };

  const handleApprove = async (planId: string) => {
    await onUpdatePlanStatus(planId, 'Approved', currentUser.name);
  };

  const handleReject = async (planId: string) => {
    await onUpdatePlanStatus(planId, 'Rejected', currentUser.name);
  };

  return (
    <div className="space-y-6" id="meal-tab-root">
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="meal-top-grid">
        
        {/* Left Card: Input Panel & Client Setup */}
        <div className="lg:col-span-4 bg-white p-6 rounded-xl border border-slate-100 shadow-xs flex flex-col justify-between h-fit" id="planner-input-card">
          <div id="planner-selector-box">
            <h3 className="font-sans font-bold text-lg text-slate-800 tracking-tight flex items-center gap-1.5 mb-2">
              <Sparkles className="w-5 h-5 text-emerald-600 animate-pulse" />
              Automated Meal Planning
            </h3>
            <p className="text-slate-500 text-xs mb-4">
              Leverage Gemini to craft sterile nutritional dishes conforming to the client's medical guidelines.
            </p>

            <div className="space-y-4" id="plan-form-controls">
              <div id="pt-select-group">
                <label className="block text-xs font-semibold text-slate-600 mb-1">Select Hospital Patient</label>
                <select
                  id="planner-pt-select"
                  className="w-full text-sm p-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                  value={selectedPatientId}
                  onChange={(e) => {
                    setSelectedPatientId(e.target.value);
                    setTempPlan(null);
                  }}
                >
                  <option value="">-- Choose admitted patient --</option>
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>{p.name} ({p.id} - Room {p.roomNumber})</option>
                  ))}
                </select>
              </div>

              {activePatient && (
                <div className="p-4 bg-slate-50 rounded-lg text-xs space-y-2.5 border border-slate-100" id="active-pt-intel">
                  <div className="flex justify-between" id="intel-gender-age">
                    <span className="text-slate-500">Gender / Age</span>
                    <span className="font-semibold text-slate-700">{activePatient.gender}, {activePatient.age} years</span>
                  </div>
                  <div className="flex justify-between" id="intel-vitals">
                    <span className="text-slate-500">Weight & Height</span>
                    <span className="font-semibold text-slate-700">{activePatient.weight} kg, {activePatient.height} cm</span>
                  </div>
                  <div className="flex justify-between text-emerald-700 font-bold" id="intel-calories">
                    <span>Intake Target</span>
                    <span className="font-mono">{activePatient.targetCalories} kcal/day</span>
                  </div>
                  <div className="pt-2 border-t border-slate-200" id="intel-conditions">
                    <span className="text-slate-500 uppercase tracking-wider text-[9px] font-bold block mb-1">Registered Conditions</span>
                    <div className="flex flex-wrap gap-1" id="intel-cond-tags">
                      {activePatient.medicalConditions.map((c, i) => (
                        <span key={i} className="bg-amber-100 text-amber-800 text-[9px] font-medium rounded-md px-1.5 py-0.5">{c}</span>
                      ))}
                    </div>
                  </div>
                  {activePatient.allergies.length > 0 && (
                    <div className="pt-2 border-t border-slate-200" id="intel-allergies">
                      <span className="text-red-600 uppercase tracking-wider text-[9px] font-bold block mb-1">Registered Allergies</span>
                      <div className="flex flex-wrap gap-1" id="intel-allergies-tags">
                        {activePatient.allergies.map((a, i) => (
                          <span key={i} className="bg-red-100 text-red-800 text-[9px] font-bold rounded-md px-1.5 py-0.5">{a}</span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="mt-6" id="planner-trigger-action">
            {activePatient ? (
              <button
                id="generate-mealplan-btn"
                onClick={triggerAIGeneration}
                disabled={isGenerating}
                className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-semibold text-xs py-3 rounded-lg shadow-sm hover:shadow-md transition flex items-center justify-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" /> {isGenerating ? 'Analyzing Vitals...' : 'Generate AI Dietary Plan'}
              </button>
            ) : (
              <div className="text-center text-slate-400 p-3 text-[11px] border border-dashed border-slate-200 rounded-lg bg-slate-50/50" id="no-pt-placeholder font-mono">
                Please select an admitted patient to begin.
              </div>
            )}
          </div>
        </div>

        {/* Right Area: Main Dynamic Workspace (Loading Screen, Pending Plan Verification, or Inactive Summary) */}
        <div className="lg:col-span-8 flex flex-col justify-stretch" id="planner-workspace-card">
          
          {/* 1. Loading Step animation */}
          {isGenerating && (
            <div className="bg-white border border-slate-150 border-slate-200 rounded-xl p-16 flex flex-col items-center justify-center text-center shadow-xs flex-1" id="generate-loading-state">
              <div className="relative mb-6" id="loading-icons-wrapper">
                <ChefHat className="w-16 h-16 text-emerald-600 animate-bounce" />
                <Sparkles className="w-6 h-6 text-amber-500 absolute -right-2 top-0 animate-spin" />
              </div>
              <h4 className="font-sans font-bold text-lg text-slate-800 tracking-tight leading-none mb-2">Analyzing Clinical Soundness</h4>
              <p className="text-xs text-slate-400 font-mono italic max-w-sm">{loadingStep}</p>
              
              <div className="w-64 h-1.5 bg-slate-100 rounded-full mt-4 overflow-hidden" id="loading-progressbar">
                <div className="h-full bg-emerald-600 rounded-full animate-pulse" style={{ width: '70%' }}></div>
              </div>
            </div>
          )}

          {/* 2. Display of Temp generated AI plan */}
          {!isGenerating && tempPlan && (
            <div className="bg-white border border-slate-100 rounded-xl p-6 shadow-xs flex-1 space-y-5" id="temp-mealplan-preview">
              <div className="flex items-center justify-between border-b border-rose-50 pb-4" id="temp-preview-header">
                <div>
                  <h4 className="font-sans font-bold text-slate-800 text-lg leading-tight tracking-tight">Clinical Preview for {activePatient?.name}</h4>
                  <p className="text-xs text-slate-500">Unapproved draft generated by clinical artificial intelligence guidelines.</p>
                </div>
                
                {/* Allergy Filter Diagnostics */}
                {tempPlan.allergyCheckPassed ? (
                  <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 font-bold text-[10px] px-3 py-1.5 rounded-full flex items-center gap-1 font-sans" id="allergy-diag-success">
                    <Check className="w-4 h-4 text-emerald-600" /> Safe: All Allergies Bypassed
                  </div>
                ) : (
                  <div className="bg-rose-50 border border-rose-100 text-rose-800 font-bold text-[10px] px-3 py-1.5 rounded-full flex items-center gap-1 font-sans animate-pulse" id="allergy-diag-fail">
                    <AlertTriangle className="w-4 h-4 text-rose-600" /> Warning: {tempPlan.flaggedAllergens.join(', ')} detected!
                  </div>
                )}
              </div>

              {/* Meals Detailed view */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="meals-draft-grid">
                
                {/* Breakfast */}
                <div className="p-4 bg-slate-50/50 rounded-lg border border-slate-150 border-slate-200 flex flex-col justify-between" id="meal-draft-breakfast">
                  <div id="br-title-row">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-600 font-mono block mb-1 flex items-center gap-1"><Coffee className="w-3 h-3" /> Breakfast</span>
                    <h5 className="font-bold text-xs text-slate-800 tracking-tight leading-snug">{tempPlan.breakfast.title}</h5>
                    
                    {/* Ingredients list */}
                    <div className="mt-2 text-[10px] text-slate-500 leading-snug" id="br-ing-list">
                      <strong className="text-[9px]">Ingredients: </strong>{tempPlan.breakfast.ingredients.join(', ')}
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center text-[10px] text-slate-500 border-t border-slate-100 pt-2 mt-3 font-mono" id="br-nutrition-bar">
                    <span>{tempPlan.breakfast.calories} kcal</span>
                    <span>P: {tempPlan.breakfast.protein}g • C: {tempPlan.breakfast.carbs}g • F: {tempPlan.breakfast.fat}g</span>
                  </div>
                </div>

                {/* Lunch */}
                <div className="p-4 bg-slate-50/50 rounded-lg border border-slate-150 border-slate-200 flex flex-col justify-between" id="meal-draft-lunch">
                  <div id="lu-title-row">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-600 font-mono block mb-1 flex items-center gap-1"><Utensils className="w-3 h-3" /> Lunch</span>
                    <h5 className="font-bold text-xs text-slate-800 tracking-tight leading-snug">{tempPlan.lunch.title}</h5>
                    
                    {/* Ingredients list */}
                    <div className="mt-2 text-[10px] text-slate-500 leading-snug" id="lu-ing-list">
                      <strong className="text-[9px]">Ingredients: </strong>{tempPlan.lunch.ingredients.join(', ')}
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center text-[10px] text-slate-500 border-t border-slate-100 pt-2 mt-3 font-mono" id="lu-nutrition-bar">
                    <span>{tempPlan.lunch.calories} kcal</span>
                    <span>P: {tempPlan.lunch.protein}g • C: {tempPlan.lunch.carbs}g • F: {tempPlan.lunch.fat}g</span>
                  </div>
                </div>

                {/* Dinner */}
                <div className="p-4 bg-slate-50/50 rounded-lg border border-slate-150 border-slate-200 flex flex-col justify-between" id="meal-draft-dinner">
                  <div id="dn-title-row">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-600 font-mono block mb-1 flex items-center gap-1"><Moon className="w-3 h-3" /> Dinner</span>
                    <h5 className="font-bold text-xs text-slate-800 tracking-tight leading-snug">{tempPlan.dinner.title}</h5>
                    
                    {/* Ingredients list */}
                    <div className="mt-2 text-[10px] text-slate-500 leading-snug" id="dn-ing-list">
                      <strong className="text-[9px]">Ingredients: </strong>{tempPlan.dinner.ingredients.join(', ')}
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center text-[10px] text-slate-500 border-t border-slate-100 pt-2 mt-3 font-mono" id="dn-nutrition-bar">
                    <span>{tempPlan.dinner.calories} kcal</span>
                    <span>P: {tempPlan.dinner.protein}g • C: {tempPlan.dinner.carbs}g • F: {tempPlan.dinner.fat}g</span>
                  </div>
                </div>

                {/* Snacks */}
                <div className="p-4 bg-slate-50/50 rounded-lg border border-slate-150 border-slate-200 flex flex-col justify-between" id="meal-draft-snack">
                  <div id="sn-title-row">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-600 font-mono block mb-1 flex items-center gap-1"><HelpCircle className="w-3 h-3" /> Nutrient Snack</span>
                    <h5 className="font-bold text-xs text-slate-800 tracking-tight leading-snug">{tempPlan.snacks.title}</h5>
                    
                    {/* Ingredients list */}
                    <div className="mt-2 text-[10px] text-slate-500 leading-snug" id="sn-ing-list">
                      <strong className="text-[9px]">Ingredients: </strong>{tempPlan.snacks.ingredients.join(', ')}
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center text-[10px] text-slate-500 border-t border-slate-100 pt-2 mt-3 font-mono" id="sn-nutrition-bar">
                    <span>{tempPlan.snacks.calories} kcal</span>
                    <span>P: {tempPlan.snacks.protein}g • C: {tempPlan.snacks.carbs}g • F: {tempPlan.snacks.fat}g</span>
                  </div>
                </div>

              </div>

              {/* Rationale and Target Calories comparison */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-emerald-50/20 border border-emerald-150 border-emerald-100 rounded-lg text-xs" id="rationales-box">
                <div id="suitability-explanation-panel">
                  <span className="font-bold flex items-center gap-1 text-emerald-800 text-[10px] uppercase font-sans"><ScrollText className="w-3.5 h-3.5" /> Clinical Suitability Rationale</span>
                  <p className="text-slate-600 text-[11px] leading-relaxed mt-1">{tempPlan.suitabilityRationale}</p>
                </div>
                <div id="draft-aggregates-panel">
                  <span className="font-bold text-slate-500 text-[10px] uppercase tracking-wide">Macro Totals check</span>
                  <div className="grid grid-cols-2 gap-2 mt-1" id="aggregates-vitals-sub">
                    <div className="p-1.5 bg-white border border-slate-200 rounded font-mono" id="aggr-cals">
                      <span className="text-[9px] text-slate-400 block uppercase">CALORIES</span>
                      <strong className="text-xs text-emerald-700">{tempPlan.totalCalories} kcal</strong>
                      <span className="text-[9px] block text-slate-400">Target: {activePatient?.targetCalories}</span>
                    </div>
                    <div className="p-1.5 bg-white border border-slate-200 rounded font-mono text-[9px] leading-tight space-y-0.5 text-slate-500" id="aggr-macros">
                      <p>Protein: <strong className="text-slate-700">{tempPlan.totalProtein}g</strong> (Target: {activePatient?.macronutrients.protein}g)</p>
                      <p>Carbs: <strong className="text-slate-700">{tempPlan.totalCarbs}g</strong> (Target: {activePatient?.macronutrients.carbs}g)</p>
                      <p>Fat: <strong className="text-slate-700">{tempPlan.totalFat}g</strong> (Target: {activePatient?.macronutrients.fat}g)</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dietitian Notes form entry */}
              <div id="dietitian-annotations-entry">
                <label className="block text-xs font-semibold text-slate-600 mb-1">Add Clinical Staff Annotations / Instructions</label>
                <textarea
                  id="dietitian-notes-input"
                  className="w-full text-xs p-2.5 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                  rows={2}
                  placeholder="e.g. Ensure low fat and sodium contents. Provide pureed or soft foods if patient exhibits difficulty."
                  value={dietitianNotesInput}
                  onChange={(e) => setDietitianNotesInput(e.target.value)}
                />
              </div>

              {/* Submit to Hospital Approval Workflow */}
              <div className="flex gap-2 justify-end" id="review-buttons-draft">
                <button
                  type="button"
                  id="cancel-draft-btn"
                  onClick={() => setTempPlan(null)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg text-xs font-semibold hover:bg-slate-50 transition cursor-pointer"
                >
                  Discard Draft
                </button>
                <button
                  type="button"
                  id="submit-audit-btn"
                  onClick={handleSaveAndSubmit}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition shadow-sm hover:shadow-md cursor-pointer"
                >
                  Submit for Doctor Approval
                </button>
              </div>

            </div>
          )}

          {/* 3. Empty/No select state */}
          {!isGenerating && !tempPlan && (
            <div className="bg-white border border-dashed border-slate-200 rounded-xl p-16 flex flex-col items-center justify-center text-center text-slate-400 flex-1" id="empty-workspace-state">
              <ScrollText className="w-12 h-12 stroke-1 mx-auto mb-2 text-slate-300" />
              <p className="text-sm font-semibold">Active Planning Workspace</p>
              <p className="text-xs text-slate-500 mt-1 max-w-sm">
                Select an admitted patient on the left panel to execute automatic safety assessments and formulate calorie budgets.
              </p>
            </div>
          )}

        </div>

      </div>

      {/* Hospital Workflow Queue: Display active plans list */}
      <div className="mt-8 bg-white border border-slate-150 border-slate-200 rounded-xl p-6 shadow-xs" id="planning-queue-section">
        <h3 className="font-sans font-bold text-base text-slate-800 tracking-tight mb-4 flex items-center gap-1.5">
          <Info className="w-5 h-5 text-emerald-600" /> Clinical Meal Plans & Approval States
        </h3>
        
        <div className="overflow-x-auto" id="queue-table-wrapper">
          <table className="w-full text-left border-collapse text-xs text-slate-600" id="plans-queue-table">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 font-mono uppercase text-[10px]">
                <th className="py-2.5 px-3">Plan ID</th>
                <th className="py-2.5 px-3">Patient Name</th>
                <th className="py-2.5 px-3">Total Calories</th>
                <th className="py-2.5 px-3 font-mono">Nutrients (P/C/F)</th>
                <th className="py-2.5 px-3">Allergy Check</th>
                <th className="py-2.5 px-3">Workflow State</th>
                <th className="py-2.5 px-3 text-right">Actions / Verification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mealPlans.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-6 text-slate-400">No active meal plans submitted to queue.</td>
                </tr>
              ) : (
                mealPlans.map((mp) => (
                  <tr key={mp.id} className="hover:bg-slate-50/50 transition">
                    <td className="py-3 px-3 font-mono font-semibold">{mp.id}</td>
                    <td className="py-3 px-3 font-sans font-bold text-slate-800">{mp.patientName}</td>
                    <td className="py-3 px-3 font-mono">{mp.totalCalories} kcal</td>
                    <td className="py-3 px-3">
                      <span className="font-mono text-slate-500">{mp.totalProtein}g / {mp.totalCarbs}g / {mp.totalFat}g</span>
                    </td>
                    <td className="py-3 px-3">
                      {mp.allergyCheckPassed ? (
                        <span className="bg-emerald-50 text-emerald-800 border border-emerald-100 text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-1 w-fit">
                          <Check className="w-3 h-3" /> Clean
                        </span>
                      ) : (
                        <span className="bg-red-50 text-red-800 border border-red-100 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 w-fit">
                          <AlertTriangle className="w-3 h-3" /> Flagged
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      {mp.status === 'Approved' ? (
                        <span className="text-emerald-700 font-semibold flex items-center gap-1">
                          <Check className="w-4 h-4 text-emerald-500" /> Approved
                        </span>
                      ) : mp.status === 'Rejected' ? (
                        <span className="text-red-700 font-semibold flex items-center gap-1">
                          <AlertOctagon className="w-4 h-4 text-red-500" /> Declined
                        </span>
                      ) : (
                        <span className="text-amber-700 font-semibold flex items-center gap-1 animate-pulse">
                          Pending Doctor Signature
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right">
                      {mp.status === 'Pending' && ['Doctor', 'Admin'].includes(currentUser.role) ? (
                        <div className="flex gap-1 justify-end">
                          <button
                            id={`approve-plan-${mp.id}`}
                            onClick={() => handleApprove(mp.id)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] px-3 py-1.5 rounded transition cursor-pointer flex items-center gap-0.5"
                          >
                            <Stethoscope className="w-3 h-3" /> Approve / Sign
                          </button>
                          <button
                            id={`decline-plan-${mp.id}`}
                            onClick={() => handleReject(mp.id)}
                            className="bg-slate-200 hover:bg-red-50 border border-slate-200 text-slate-700 hover:text-red-600 hover:border-red-200 font-bold text-[10px] px-3 py-1.5 rounded transition cursor-pointer"
                          >
                            Reject
                          </button>
                        </div>
                      ) : mp.status === 'Approved' ? (
                        <span className="text-[10px] text-slate-400 font-mono block italic">Signed by {mp.approvedBy}</span>
                      ) : mp.status === 'Rejected' ? (
                        <span className="text-[10px] text-red-500 font-mono block">Rejected by Staff</span>
                      ) : (
                        <span className="text-[10px] text-slate-400 block italic">Pending clinical authorization</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
