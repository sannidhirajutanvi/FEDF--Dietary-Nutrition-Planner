/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, UserRole } from '../types.js';
import { Shield, Key, Sparkles, UserCheck, Stethoscope, Carrot, ChefHat, LayoutGrid, UserPlus, ArrowRight, Bed, HeartHandshake } from 'lucide-react';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
}

export default function LoginScreen({ onLoginSuccess }: LoginProps) {
  // Toggle between 'staff' or 'patient' portals
  const [portal, setPortal] = useState<'staff' | 'patient'>('staff');
  
  // Staff states
  const [isRegistering, setIsRegistering] = useState(false);
  const [role, setRole] = useState<UserRole>('Dietitian');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState('');
  const [password, setPassword] = useState('');
  
  // Patient states
  const [patientId, setPatientId] = useState('');
  const [patientName, setPatientName] = useState('');
  
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Preset accounts for healthcare professionals
  const presetStaff = [
    {
      name: 'Dr. Sarah Peterson',
      role: 'Doctor' as UserRole,
      email: 's.peterson@hospital.org',
      department: 'Cardiology',
      icon: Stethoscope
    },
    {
      name: 'Carol Danes, RD',
      role: 'Dietitian' as UserRole,
      email: 'carol.nutrition@hospital.org',
      department: 'Nutrient Analytics',
      icon: Carrot
    },
    {
      name: 'Chef Robert V.',
      role: 'KitchenStaff' as UserRole,
      email: 'robert.kitchen@hospital.org',
      department: 'Culinary Logistics',
      icon: ChefHat
    },
    {
      name: 'Chief Admin Davis',
      role: 'Admin' as UserRole,
      email: 'admin.ops@hospital.org',
      department: 'Hospital Administration',
      icon: LayoutGrid
    }
  ];

  // Preset accounts for active inpatients to showcase the patient app companion panel
  const presetPatients = [
    { id: 'P-101', name: 'James Vance', ward: 'Cardiology', room: 'A-302' },
    { id: 'P-102', name: 'Emma Lin', ward: 'Obstetrics & Gynecology', room: 'B-108' },
    { id: 'P-103', name: 'Marcus Brody', ward: 'General Medicine', room: 'A-105' },
    { id: 'P-104', name: 'Sophia Martinez', ward: 'Geriatrics', room: 'C-214' }
  ];

  // Load custom registered users from localStorage
  const getRegisteredUsers = (): any[] => {
    try {
      const stored = localStorage.getItem('h_dietary_users');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  };

  const handleStaffLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email) {
      setError('Please provide a valid staff email.');
      return;
    }

    // Custom logins or bypass presets
    const customUsers = getRegisteredUsers();
    const foundCustom = customUsers.find(
      u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );

    if (foundCustom) {
      onLoginSuccess({
        id: foundCustom.id,
        name: foundCustom.name,
        email: foundCustom.email,
        role: foundCustom.role,
        department: foundCustom.department
      });
      return;
    }

    const foundPreset = presetStaff.find(p => p.email.toLowerCase() === email.toLowerCase());
    const userName = foundPreset ? foundPreset.name : email.split('@')[0].replace('.', ' ');
    const userDept = foundPreset ? foundPreset.department : 'General Ward Support';
    const userRole = foundPreset ? foundPreset.role : role;

    onLoginSuccess({
      id: `USR-${Math.floor(Math.random() * 900) + 100}`,
      name: userName.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
      email: email.toLowerCase(),
      role: userRole,
      department: userDept
    });
  };

  const handlePatientLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const targetId = patientId.trim().toUpperCase();
    const targetName = patientName.trim();

    if (!targetId && !targetName) {
      setError('Please provide your Patient ID or Admission Name.');
      return;
    }

    // Try finding in preset patients first
    let matchedPatient = presetPatients.find(
      p => p.id.toUpperCase() === targetId || p.name.toLowerCase() === targetName.toLowerCase()
    );

    if (!matchedPatient) {
      // Create transient testing patient user
      matchedPatient = {
        id: targetId || `P-${Math.floor(Math.random() * 800) + 100}`,
        name: targetName || 'Guest Patient',
        ward: 'General Medicine',
        room: 'A-101'
      };
    }

    onLoginSuccess({
      id: matchedPatient.id,
      name: matchedPatient.name,
      role: 'Patient', // Custom patient user role triggers simplification filters
      email: `${matchedPatient.id.toLowerCase()}@patient.hospital.org`,
      department: matchedPatient.ward
    });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!name.trim()) {
      setError('Please provide your full staff name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please enter a valid work email address.');
      return;
    }
    if (!department.trim()) {
      setError('Please specify your medical department.');
      return;
    }

    const customUsers = getRegisteredUsers();
    const newUser = {
      id: `USR-${Math.floor(Math.random() * 900) + 100}`,
      name: name.trim().split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
      email: email.trim().toLowerCase(),
      role,
      department: department.trim(),
      password
    };

    localStorage.setItem('h_dietary_users', JSON.stringify([...customUsers, newUser]));
    
    setSuccess('Registration successful! Logging in...');
    setTimeout(() => {
      onLoginSuccess({
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        department: newUser.department
      });
    }, 1000);
  };

  const loginAsPatientPreset = (p: typeof presetPatients[0]) => {
    onLoginSuccess({
      id: p.id,
      name: p.name,
      role: 'Patient',
      email: `${p.id.toLowerCase()}@patient.hospital.org`,
      department: p.ward
    });
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col items-center justify-center p-6 md:p-12 font-sans selection:bg-black selection:text-white" id="login-screen-outer">
      
      {/* Brand Icon Header */}
      <div className="mb-8 flex flex-col items-center text-center" id="brand-headline">
        <div className="p-3 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center mb-3">
          <Shield className="w-6 h-6 text-slate-800" />
        </div>
        <h1 className="font-sans font-extrabold text-2xl tracking-tight text-slate-900">NutriPlan Console</h1>
        <p className="text-slate-450 text-xs mt-1 max-w-sm">
          A modern clinical meal planner & inpatient nutrition tracker.
        </p>
      </div>

      <div className="w-full max-w-md bg-white rounded-3xl border border-slate-100 shadow-xl shadow-slate-100/40 p-6 md:p-8" id="login-container">
        
        {/* Apple-Style Minimal Tab Switcher between Staff & Patient Portals */}
        <div className="bg-slate-100 p-1 rounded-2xl flex gap-1 mb-8" id="portal-tab-switcher">
          <button
            type="button"
            id="tab-staff-portal"
            onClick={() => {
              setPortal('staff');
              setError('');
              setSuccess('');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition duration-150 cursor-pointer flex items-center justify-center gap-1.5 ${
              portal === 'staff' 
                ? 'bg-white text-slate-900 shadow-sm font-extrabold'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Stethoscope className="w-3.5 h-3.5" />
            Medical Staff
          </button>
          <button
            type="button"
            id="tab-patient-portal"
            onClick={() => {
              setPortal('patient');
              setError('');
              setSuccess('');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition duration-150 cursor-pointer flex items-center justify-center gap-1.5 ${
              portal === 'patient' 
                ? 'bg-white text-slate-900 shadow-sm font-extrabold'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Bed className="w-3.5 h-3.5" />
            Inpatient Companion
          </button>
        </div>

        {/* Global form errors */}
        {error && (
          <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 text-xs rounded-xl flex items-center mb-6 font-sans font-semibold transition" id="login-error-pill">
            <Sparkles className="w-3.5 h-3.5 mr-2 text-rose-500 shrink-0" />
            {error}
          </div>
        )}
        {success && (
          <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-800 text-xs rounded-xl flex items-center mb-6 font-sans font-semibold transition" id="login-success-pill">
            <Sparkles className="w-3.5 h-3.5 mr-2 text-emerald-500 shrink-0 animate-pulse" />
            {success}
          </div>
        )}

        {/* PORTAL VIEW A: STAFF LOGIN */}
        {portal === 'staff' && !isRegistering && (
          <form onSubmit={handleStaffLogin} className="space-y-5" id="staff-login-form">
            <div id="staff-quick-login-header">
              <span className="text-[10px] uppercase font-mono tracking-widest text-slate-400 block font-bold mb-3">Instant Trial Logins</span>
              <div className="grid grid-cols-2 gap-2" id="staff-preset-grid">
                {presetStaff.map((p, idx) => {
                  const Icon = p.icon;
                  return (
                    <button
                      key={idx}
                      type="button"
                      id={`preset-staff-${p.role}`}
                      onClick={() => onLoginSuccess({
                        id: `USR-${100 + idx}`,
                        name: p.name,
                        role: p.role,
                        email: p.email,
                        department: p.department
                      })}
                      className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300 transition text-left cursor-pointer group active:scale-98"
                    >
                      <div className="p-1.5 bg-white text-slate-500 group-hover:text-slate-900 rounded-lg shadow-2xs border border-slate-100">
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <div className="overflow-hidden">
                        <p className="font-extrabold text-slate-800 text-[10px] truncate leading-tight">{p.name.split(' ')[0]} {p.name.split(' ')[1]?.charAt(0)}.</p>
                        <span className="text-[8px] font-mono text-slate-400 block tracking-wider uppercase">{p.role === 'KitchenStaff' ? 'Kitchen' : p.role}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="relative flex items-center justify-center my-6" id="divider-staff">
              <div className="border-t border-slate-100 w-full"></div>
              <span className="absolute bg-white px-3 text-[8px] font-mono tracking-widest text-slate-400 uppercase">Or Secure Entry</span>
            </div>

            <div className="space-y-4" id="staff-fields">
              <div id="staff-email-gp">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1.5">Staff Work Email</label>
                <div className="relative">
                  <input
                    type="email"
                    id="staff-email-input"
                    className="w-full text-xs p-3 pl-10 border border-slate-200 focus:border-slate-900 rounded-xl bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none transition-all text-slate-800 font-sans"
                    placeholder="name@hospital.org"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  <UserCheck className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                </div>
              </div>

              <div id="staff-password-gp">
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono">Access PIN / Password</label>
                  <span className="text-[9px] font-mono text-slate-400">Default: any PIN</span>
                </div>
                <div className="relative">
                  <input
                    type="password"
                    id="staff-password-input"
                    className="w-full text-xs p-3 pl-10 border border-slate-200 focus:border-slate-900 rounded-xl bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none transition-all text-slate-800 font-sans"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <Key className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                </div>
              </div>
            </div>

            <button
              type="submit"
              id="staff-signin-btn"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white p-3 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer font-sans shadow-sm"
            >
              Enter Care Console <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <div className="text-center pt-2" id="toggle-staff-register">
              <button
                type="button"
                id="btn-go-register"
                onClick={() => {
                  setError('');
                  setSuccess('');
                  setIsRegistering(true);
                }}
                className="text-xs text-slate-500 hover:text-slate-900 font-bold transition cursor-pointer underline underline-offset-2"
              >
                Create manual medical credentials
              </button>
            </div>
          </form>
        )}

        {/* PORTAL VIEW B: PATIENT PORTAL LOGIN */}
        {portal === 'patient' && (
          <form onSubmit={handlePatientLogin} className="space-y-5" id="patient-login-form">
            <div id="patient-quick-login-header">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] uppercase font-mono tracking-widest text-slate-400 block font-bold">Select Admitted Inpatient</span>
                <span className="text-[9px] font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full font-bold">Bed Synchronized</span>
              </div>
              <div className="grid grid-cols-1 gap-2" id="patient-preset-grid">
                {presetPatients.map((p, idx) => (
                  <button
                    key={p.id}
                    type="button"
                    id={`preset-pt-${p.id}`}
                    onClick={() => loginAsPatientPreset(p)}
                    className="flex justify-between items-center p-3 rounded-xl border border-slate-100 bg-slate-50/40 hover:bg-slate-100/50 hover:border-slate-350 transition text-left cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center text-[10px] font-bold border border-emerald-100 font-mono">
                        {p.id}
                      </div>
                      <div>
                        <p className="font-extrabold text-slate-800 text-xs leading-none group-hover:text-black transition-colors">{p.name}</p>
                        <span className="text-[9px] font-sans text-slate-400 block mt-1">{p.ward} • Room {p.room}</span>
                      </div>
                    </div>
                    <div className="text-slate-400 group-hover:text-slate-800 transition">
                      <ArrowRight className="w-4 h-4 translate-x-0 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="relative flex items-center justify-center my-6" id="divider-patient">
              <div className="border-t border-slate-100 w-full"></div>
              <span className="absolute bg-white px-3 text-[8px] font-mono tracking-widest text-slate-400 uppercase">Or Admitted Name Search</span>
            </div>

            <div className="space-y-4" id="patient-fields">
              <div id="patient-name-gp">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1.5">Your Full Registered Name</label>
                <div className="relative">
                  <input
                    type="text"
                    id="patient-name-input"
                    className="w-full text-xs p-3 pl-10 border border-slate-200 focus:border-slate-900 rounded-xl bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none transition-all text-slate-800 font-sans"
                    placeholder="e.g. James Vance"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                  />
                  <UserCheck className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                </div>
              </div>

              <div id="patient-id-gp">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1.5">Inpatient ID Number (Optional)</label>
                <div className="relative">
                  <input
                    type="text"
                    id="patient-id-input"
                    className="w-full text-xs p-3 pl-10 border border-slate-200 focus:border-slate-900 rounded-xl bg-slate-50/50 hover:bg-slate-50 focus:bg-white focus:outline-none transition-all text-slate-800 font-sans uppercase font-mono"
                    placeholder="e.g. P-101"
                    value={patientId}
                    onChange={(e) => setPatientId(e.target.value)}
                  />
                  <Key className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                </div>
              </div>
            </div>

            <button
              type="submit"
              id="patient-companion-btn"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white p-3 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer font-sans shadow-sm"
            >
              Sign In to Patient Companion <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        )}

        {/* STAFF REGISTRATION FORM */}
        {portal === 'staff' && isRegistering && (
          <form onSubmit={handleRegister} className="space-y-4" id="staff-register-form">
            <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider font-mono">Create Medical Credentials</h3>
            
            <div id="register-role-gp">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1 px-1">Institutional Role</label>
              <div className="bg-slate-100 p-1 rounded-xl flex gap-1" id="reg-role-selector">
                {(['Dietitian', 'Doctor', 'KitchenStaff', 'Admin'] as UserRole[]).map((r) => (
                  <button
                    type="button"
                    key={r}
                    id={`reg-role-${r}`}
                    onClick={() => {
                      setRole(r);
                      if (r === 'Doctor') setDepartment('Cardiology');
                      else if (r === 'Dietitian') setDepartment('Nutrient Analytics');
                      else if (r === 'KitchenStaff') setDepartment('Culinary Logistics');
                      else setDepartment('Hospital Administration');
                    }}
                    className={`flex-1 py-1 text-[10px] text-center rounded-lg font-sans font-bold transition-all cursor-pointer ${
                      role === r
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-450 hover:text-slate-700'
                    }`}
                  >
                    {r === 'KitchenStaff' ? 'Kitchen' : r}
                  </button>
                ))}
              </div>
            </div>

            <div id="reg-name-gp">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1">Full Doctor / Staff Name</label>
              <input
                type="text"
                required
                id="reg-name-input"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:border-slate-900 focus:outline-none bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-800 font-sans"
                placeholder="e.g. Dr. Elizabeth Thorne"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-3" id="reg-subfields">
              <div id="reg-email-gp">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1">Work Email</label>
                <input
                  type="email"
                  required
                  id="reg-email-input"
                  className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:border-slate-900 focus:outline-none bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-800 font-sans"
                  placeholder="name@hospital.org"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div id="reg-dept-gp">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1">Department</label>
                <input
                  type="text"
                  required
                  id="reg-dept-input"
                  className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:border-slate-900 focus:outline-none bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-800 font-sans"
                  placeholder="e.g. Geriatrics"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                />
              </div>
            </div>

            <div id="reg-pwd-gp">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1">Access PIN / Password</label>
              <input
                type="password"
                required
                id="reg-pwd-input"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:border-slate-900 focus:outline-none bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-800 font-sans"
                placeholder="minimum 4 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button
              type="submit"
              id="reg-submit-btn"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white p-3 text-xs font-bold rounded-xl transition cursor-pointer font-sans shadow-sm flex items-center justify-center gap-1"
            >
              <UserPlus className="w-3.5 h-3.5 text-slate-300" /> Complete Registration
            </button>

            <div className="text-center pt-1" id="toggle-reg-back">
              <button
                type="button"
                id="btn-back-login"
                onClick={() => {
                  setError('');
                  setSuccess('');
                  setIsRegistering(false);
                }}
                className="text-xs text-slate-500 hover:text-slate-900 font-bold transition cursor-pointer underline underline-offset-2"
              >
                Cancel and return to sign in
              </button>
            </div>
          </form>
        )}

      </div>

      <div className="mt-8 text-center text-[10px] font-mono text-slate-400 flex items-center gap-1.5" id="compliance-footer">
        <HeartHandshake className="w-3.5 h-3.5 text-slate-300" />
        Symmetric Care Coordination • HIPPA Compliant Encryption
      </div>
    </div>
  );
}
