/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Patient, MealPlan, KitchenOrder } from '../types.js';
import { Search, Plus, Trash2, Edit, CheckCircle2, User, Activity, AlertOctagon, RefreshCw, X } from 'lucide-react';
import { calculateDailyTargetCalories, calculateMacronutrients } from '../utils/calorieCalculator.js';

interface PatientTabProps {
  patients: Patient[];
  onAddPatient: (patient: Omit<Patient, 'id'>) => Promise<void>;
  onUpdatePatient: (id: string, updates: Partial<Patient>) => Promise<void>;
  onDeletePatient: (id: string) => Promise<void>;
  userRole: string;
  mealPlans?: MealPlan[];
  kitchenOrders?: KitchenOrder[];
}

const COMMON_CONDITIONS = ['Hypertension', 'Type 2 Diabetes', 'Gestational Diabetes', 'CKD Stage 3', 'Hypercholesterolemia', 'Post-Op Recovery', 'Osteoporosis'];
const COMMON_ALLERGENS = ['Peanuts', 'Dairy', 'Gluten', 'Shellfish', 'Soy', 'Walnuts', 'Eggs', 'Tree Nuts'];

export default function PatientProfileTab({ 
  patients, 
  onAddPatient, 
  onUpdatePatient, 
  onDeletePatient, 
  userRole,
  mealPlans = [],
  kitchenOrders = []
}: PatientTabProps) {
  const [search, setSearch] = useState('');
  const [selectedWard, setSelectedWard] = useState('All');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);

  // Form Field States
  const [name, setName] = useState('');
  const [age, setAge] = useState<number>(45);
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [weight, setWeight] = useState<number>(70);
  const [height, setHeight] = useState<number>(170);
  const [ward, setWard] = useState('General Medicine');
  const [roomNumber, setRoomNumber] = useState('');
  const [activityLevel, setActivityLevel] = useState<'Sedentary' | 'Light' | 'Moderate' | 'Active'>('Sedentary');
  const [stressFactor, setStressFactor] = useState<number>(1.2); // Minor Surgery / Post-Op
  const [medicalConditions, setMedicalConditions] = useState<string[]>([]);
  const [allergies, setAllergies] = useState<string[]>([]);
  
  // Custom inputs
  const [customCondition, setCustomCondition] = useState('');
  const [customAllergen, setCustomAllergen] = useState('');

  // Live calculated fields
  const [liveCalories, setLiveCalories] = useState(1800);
  const [liveMacros, setLiveMacros] = useState({ protein: 90, carbs: 220, fat: 50 });

  // Handle live updates
  useEffect(() => {
    const calculatedCals = calculateDailyTargetCalories({
      age,
      gender,
      weight,
      height,
      activityLevel,
      stressFactor
    });
    const calculatedMacros = calculateMacronutrients(calculatedCals, medicalConditions);
    
    setLiveCalories(calculatedCals);
    setLiveMacros(calculatedMacros);
  }, [age, gender, weight, height, activityLevel, stressFactor, medicalConditions]);

  const resetForm = () => {
    setName('');
    setAge(45);
    setGender('Male');
    setWeight(70);
    setHeight(170);
    setWard('General Medicine');
    setRoomNumber('');
    setActivityLevel('Sedentary');
    setStressFactor(1.2);
    setMedicalConditions([]);
    setAllergies([]);
    setEditingPatient(null);
    setCustomCondition('');
    setCustomAllergen('');
  };

  const handleOpenAddForm = () => {
    resetForm();
    setIsFormOpen(true);
  };

  const handleOpenEditForm = (p: Patient) => {
    setEditingPatient(p);
    setName(p.name);
    setAge(p.age);
    setGender(p.gender);
    setWeight(p.weight);
    setHeight(p.height);
    setWard(p.ward);
    setRoomNumber(p.roomNumber);
    setActivityLevel(p.activityLevel);
    setMedicalConditions(p.medicalConditions);
    setAllergies(p.allergies);
    setIsFormOpen(true);
    // Find approximate stress factor
    if (p.medicalConditions.some(c => c.toLowerCase().includes('post-op'))) {
      setStressFactor(1.2);
    } else {
      setStressFactor(1.0);
    }
  };

  const toggleCondition = (cond: string) => {
    if (medicalConditions.includes(cond)) {
      setMedicalConditions(medicalConditions.filter(c => c !== cond));
    } else {
      setMedicalConditions([...medicalConditions, cond]);
    }
  };

  const toggleAllergy = (allergy: string) => {
    if (allergies.includes(allergy)) {
      setAllergies(allergies.filter(a => a !== allergy));
    } else {
      setAllergies([...allergies, allergy]);
    }
  };

  const handleAddCustomCondition = () => {
    if (customCondition && !medicalConditions.includes(customCondition)) {
      setMedicalConditions([...medicalConditions, customCondition]);
      setCustomCondition('');
    }
  };

  const handleAddCustomAllergy = () => {
    if (customAllergen && !allergies.includes(customAllergen)) {
      setAllergies([...allergies, customAllergen]);
      setCustomAllergen('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !roomNumber.trim()) return;

    const patientData = {
      name,
      age,
      gender,
      weight,
      height,
      activityLevel,
      medicalConditions,
      allergies,
      roomNumber,
      ward,
      admissionDate: editingPatient ? editingPatient.admissionDate : new Date().toISOString().substring(0, 10),
      targetCalories: liveCalories,
      macronutrients: liveMacros
    };

    if (editingPatient) {
      await onUpdatePatient(editingPatient.id, patientData);
    } else {
      await onAddPatient(patientData);
    }
    resetForm();
    setIsFormOpen(false);
  };

  // Filter list
  const filteredPatients = patients.filter((p) => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          p.id.toLowerCase().includes(search.toLowerCase()) ||
                          p.ward.toLowerCase().includes(search.toLowerCase()) ||
                          p.roomNumber.toLowerCase().includes(search.toLowerCase());
    const matchesWard = selectedWard === 'All' || p.ward === selectedWard;
    return matchesSearch && matchesWard;
  });

  const uniqueWards = Array.from(new Set(patients.map(p => p.ward)));

  return (
    <div className="space-y-6" id="patient-tab-root">
      
      {/* Top Header Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-4 rounded-xl border border-slate-100 shadow-xs" id="patient-controls">
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto" id="search-filter-inputs">
          <div className="relative shrink-0" id="search-input-wrapper">
            <input
              type="text"
              placeholder="Search patients by name / ID..."
              id="patient-search-input"
              className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg w-64 focus:outline-none focus:border-emerald-500 transition"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </div>
          
          <select
            id="ward-filter-select"
            className="text-sm border border-slate-200 rounded-lg px-3 py-2 bg-white focus:outline-none focus:border-emerald-500 transition"
            value={selectedWard}
            onChange={(e) => setSelectedWard(e.target.value)}
          >
            <option value="All">All Wards</option>
            {uniqueWards.map(w => (
              <option key={w} value={w}>{w}</option>
            ))}
          </select>
        </div>

        {/* Doctor and Admin can register patients */}
        {['Dietitian', 'Doctor', 'Admin'].includes(userRole) && (
          <button
            id="add-patient-btn"
            onClick={handleOpenAddForm}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg transition shadow-sm hover:shadow-md flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Add Admitted Patient
          </button>
        )}
      </div>

      {/* Adding/Editing Modal Drawer */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="patient-modal">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl max-w-4xl w-full p-6 relative max-h-[90vh] overflow-y-auto" id="patient-form-card">
            
            <button
              id="close-modal-btn"
              type="button"
              className="absolute right-4 top-4 p-2 text-slate-400 hover:text-slate-600 rounded-full transition hover:bg-slate-50 cursor-pointer"
              onClick={() => setIsFormOpen(false)}
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-sans font-bold text-xl text-slate-800 tracking-tight" id="modal-title">
              {editingPatient ? `Edit Profile: ${editingPatient.name}` : 'Register New Inpatient'}
            </h3>
            <p className="text-slate-500 text-xs mt-0.5">Maintain sterile telemetry. Calculates calories automatically using medical adjustments.</p>

            <form onSubmit={handleSubmit} className="mt-4 grid grid-cols-1 md:grid-cols-12 gap-6" id="patient-form">
              
              {/* Form entries */}
              <div className="md:col-span-7 space-y-4" id="form-entries-column">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="demographic-subgrid">
                  <div id="pt-name-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Patient Full Name</label>
                    <input
                      required
                      type="text"
                      id="pt-name-field"
                      className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                      placeholder="e.g. Johnathan Smith"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                  <div id="pt-room-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Room No. & Bed</label>
                    <input
                      required
                      type="text"
                      id="pt-room-field"
                      className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                      placeholder="e.g. Room A-302 / Bed B"
                      value={roomNumber}
                      onChange={(e) => setRoomNumber(e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2" id="vitals-subgrid">
                  <div id="pt-age-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Age (Years)</label>
                    <input
                      type="number"
                      id="pt-age-field"
                      className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                      value={age}
                      onChange={(e) => setAge(Number(e.target.value))}
                    />
                  </div>
                  <div id="pt-weight-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Weight (kg)</label>
                    <input
                      type="number"
                      id="pt-weight-field"
                      className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                      value={weight}
                      onChange={(e) => setWeight(Number(e.target.value))}
                    />
                  </div>
                  <div id="pt-height-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Height (cm)</label>
                    <input
                      type="number"
                      id="pt-height-field"
                      className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                      value={height}
                      onChange={(e) => setHeight(Number(e.target.value))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="logistics-subgrid">
                  <div id="pt-gender-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Genders</label>
                    <div className="flex gap-2" id="gender-btn-wrapper">
                      {(['Male', 'Female'] as const).map((g) => (
                        <button
                          type="button"
                          key={g}
                          id={`gender-select-${g}`}
                          onClick={() => setGender(g)}
                          className={`flex-1 py-1.5 text-xs rounded-lg border text-center transition cursor-pointer ${
                            gender === g
                              ? 'bg-emerald-600 text-white font-medium border-emerald-600'
                              : 'bg-white text-slate-600 border-slate-200'
                          }`}
                        >
                          {g}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div id="pt-ward-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Staff Ward Division</label>
                    <select
                      id="pt-ward-field"
                      className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                      value={ward}
                      onChange={(e) => setWard(e.target.value)}
                    >
                      <option value="General Medicine">General Medicine</option>
                      <option value="Cardiology">Cardiology</option>
                      <option value="Geriatrics">Geriatrics</option>
                      <option value="Obstetrics & Gynecology">Obstetrics & Gynecology</option>
                      <option value="Pediatrics">Pediatrics</option>
                      <option value="Surgical ICU">Surgical ICU</option>
                    </select>
                  </div>
                </div>

                {/* Conditions Tags Selection */}
                <div id="pt-conditions-tags">
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Medical Conditions (Select tags)</label>
                  <div className="flex flex-wrap gap-1 mb-2" id="preset-conditions-grid">
                    {COMMON_CONDITIONS.map((cond) => {
                      const isSelected = medicalConditions.includes(cond);
                      return (
                        <button
                          type="button"
                          key={cond}
                          id={`condition-chk-${cond}`}
                          onClick={() => toggleCondition(cond)}
                          className={`text-[10px] px-2 py-1 rounded-full border transition cursor-pointer ${
                            isSelected
                              ? 'bg-amber-100 text-amber-800 border-amber-300 font-semibold'
                              : 'bg-slate-50 text-slate-600 border-slate-200'
                          }`}
                        >
                          {cond}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex gap-2" id="custom-condition-add">
                    <input
                      type="text"
                      placeholder="Add other medical condition..."
                      id="custom-condition-field"
                      className="flex-1 text-xs p-1.5 border border-slate-200 rounded-lg focus:outline-none"
                      value={customCondition}
                      onChange={(e) => setCustomCondition(e.target.value)}
                    />
                    <button
                      type="button"
                      id="custom-condition-btn"
                      onClick={handleAddCustomCondition}
                      className="bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 text-xs px-3 rounded-lg cursor-pointer"
                    >
                      Add
                    </button>
                  </div>
                </div>

                {/* Allergies Selection */}
                <div id="pt-allergies-tags">
                  <label className="block text-xs font-semibold text-red-600 mb-1">Allergy Warnings (Safety Checked)</label>
                  <div className="flex flex-wrap gap-1 mb-2" id="preset-allergies-grid">
                    {COMMON_ALLERGENS.map((all) => {
                      const isSelected = allergies.includes(all);
                      return (
                        <button
                          type="button"
                          key={all}
                          id={`allergy-chk-${all}`}
                          onClick={() => toggleAllergy(all)}
                          className={`text-[10px] px-2 py-1 rounded-full border transition cursor-pointer ${
                            isSelected
                              ? 'bg-red-100 text-red-800 border-red-300 font-bold'
                              : 'bg-slate-50 text-slate-600 border-slate-200'
                          }`}
                        >
                          {all}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex gap-2" id="custom-allergy-add">
                    <input
                      type="text"
                      placeholder="Add other allergy..."
                      id="custom-allergy-field"
                      className="flex-1 text-xs p-1.5 border border-slate-200 rounded-lg focus:outline-none"
                      value={customAllergen}
                      onChange={(e) => setCustomAllergen(e.target.value)}
                    />
                    <button
                      type="button"
                      id="custom-allergy-btn"
                      onClick={handleAddCustomAllergy}
                      className="bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 text-xs px-3 rounded-lg cursor-pointer"
                    >
                      Add
                    </button>
                  </div>
                </div>

                {/* Activity & Health multipliers */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="clinical-multipliers">
                  <div id="pt-activity-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Activity Levels</label>
                    <select
                      id="pt-activity-field"
                      className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                      value={activityLevel}
                      onChange={(e) => setActivityLevel(e.target.value as any)}
                    >
                      <option value="Sedentary">Sedentary (Strict Bedrest)</option>
                      <option value="Light">Lightly Active (Ambulatory)</option>
                      <option value="Moderate">Moderately Active (Rehab)</option>
                      <option value="Active">Highly Active (Postpartum, etc.)</option>
                    </select>
                  </div>
                  <div id="pt-stress-group">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Clinical Stress Factors</label>
                    <select
                      id="pt-stress-field"
                      className="w-full text-sm p-2 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500"
                      value={stressFactor}
                      onChange={(e) => setStressFactor(Number(e.target.value))}
                    >
                      <option value="1.0">No Acute Stress / Outpatient (1.0x)</option>
                      <option value="1.15">Underweight Refeeding Recovery (1.15x)</option>
                      <option value="1.2">Minor Post-Op / Stable Surgery (1.2x)</option>
                      <option value="1.4">Severe Infection / Inflammatory (1.4x)</option>
                      <option value="1.6">Extreme Burns / Trauma Recovery (1.6x)</option>
                    </select>
                  </div>
                </div>

              </div>

              {/* Right Side Column: Live Calculations Display */}
              <div className="md:col-span-5 bg-emerald-50/50 p-6 rounded-xl border border-emerald-200 flex flex-col justify-between" id="calculator-sidebar">
                <div id="live-calc-results">
                  <div className="flex items-center gap-1.5 text-emerald-800 mb-3" id="live-calc-header">
                    <Activity className="w-5 h-5 text-emerald-600" />
                    <h4 className="font-sans font-bold text-sm tracking-tight">Clinical Calorie Assessment</h4>
                  </div>

                  <p className="text-[11px] text-emerald-950 leading-relaxed max-w-xs mb-4">
                    Live dynamic estimation of caloric targets modeled on Benedict formulae adjusted for stress.
                  </p>

                  <div className="bg-white p-4 rounded-lg border border-emerald-150 border-emerald-200 text-center shadow-xs mb-4" id="calories-display-card">
                    <span className="text-[10px] font-mono tracking-wider font-semibold uppercase text-slate-400">Total BMR kcal Requirement</span>
                    <h2 className="font-mono text-3xl font-bold text-emerald-700 leading-tight my-1">{liveCalories} <span className="text-xs font-sans text-slate-500 font-normal">kcal/day</span></h2>
                  </div>

                  {/* Macros grams */}
                  <div className="space-y-3" id="macros-display">
                    <div>
                      <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1">
                        <span>Protein Target</span>
                        <span className="font-mono text-emerald-700">{liveMacros.protein}g</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.min(100, (liveMacros.protein / 150) * 100)}%` }}></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1">
                        <span>Carbohydrates Target</span>
                        <span className="font-mono text-amber-700">{liveMacros.carbs}g</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-500 rounded-full" style={{ width: `${Math.min(100, (liveMacros.carbs / 300) * 100)}%` }}></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1">
                        <span>Dietary Fats Target</span>
                        <span className="font-mono text-slate-700">{liveMacros.fat}g</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-slate-500 rounded-full" style={{ width: `${Math.min(100, (liveMacros.fat / 100) * 100)}%` }}></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6" id="form-submit-buttons">
                  <button
                    type="submit"
                    id="save-patient-btn"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-3 rounded-lg shadow-sm hover:shadow-md transition flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Save Patient Profile
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Patient Grid Listing */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="patients-grid">
        {filteredPatients.length === 0 ? (
          <div className="col-span-full border border-dashed border-slate-200 rounded-xl p-12 text-center text-slate-400" id="empty-patients-state">
            <User className="w-12 h-12 stroke-1 mx-auto mb-2 text-slate-300" />
            <p className="text-sm font-semibold">No inpatient profiles match filter criteria</p>
            <p className="text-xs text-slate-500 mt-1">Adjust search metrics or register a new admitted patient.</p>
          </div>
        ) : (
          filteredPatients.map((p) => {
            const approvedPlan = mealPlans.find(mp => mp.patientId === p.id && mp.status === 'Approved');
            
            let consumedCalories = 0;
            if (approvedPlan) {
              const patientDeliveredOrders = kitchenOrders.filter(
                o => o.patientId === p.id && o.status === 'Delivered'
              );
              
              patientDeliveredOrders.forEach(o => {
                const mealTimeLower = o.mealTime.toLowerCase();
                if (mealTimeLower === 'breakfast' && approvedPlan.breakfast) {
                  consumedCalories += approvedPlan.breakfast.calories || 0;
                } else if (mealTimeLower === 'lunch' && approvedPlan.lunch) {
                  consumedCalories += approvedPlan.lunch.calories || 0;
                } else if (mealTimeLower === 'dinner' && approvedPlan.dinner) {
                  consumedCalories += approvedPlan.dinner.calories || 0;
                } else if ((mealTimeLower === 'snack' || mealTimeLower === 'snacks') && approvedPlan.snacks) {
                  consumedCalories += approvedPlan.snacks.calories || 0;
                }
              });
            }

            const percentOfGoal = p.targetCalories > 0 
              ? Math.min(100, Math.round((consumedCalories / p.targetCalories) * 100)) 
              : 0;

            const radius = 13;
            const circumference = 2 * Math.PI * radius; // ~81.68
            const strokeDashoffset = circumference - (percentOfGoal / 100) * circumference;

            return (
              <div
                key={p.id}
                id={`patient-card-${p.id}`}
                className="bg-white rounded-xl border border-slate-100 shadow-xs hover:shadow-sm hover:border-slate-200 transition overflow-hidden flex flex-col justify-between"
              >
                <div className="p-5" id={`patient-body-${p.id}`}>
                  <div className="flex items-start justify-between mb-3" id={`patient-head-row-${p.id}`}>
                    <div>
                      <span className="font-mono text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-md font-semibold">{p.id}</span>
                      <h4 className="font-sans font-bold text-slate-800 text-base tracking-tight leading-snug mt-1">{p.name}</h4>
                      <p className="text-[11px] text-slate-500 tracking-tight font-sans mt-0.5">Room {p.roomNumber} • Ward {p.ward}</p>
                    </div>
                    
                    {/* Action buttons if privileged */}
                    {['Dietitian', 'Doctor', 'Admin'].includes(userRole) && (
                      <div className="flex gap-1" id={`patient-acts-${p.id}`}>
                        <button
                          id={`edit-pt-${p.id}`}
                          onClick={() => handleOpenEditForm(p)}
                          className="p-1 text-slate-400 hover:text-emerald-600 rounded-md transition hover:bg-slate-50 cursor-pointer"
                          title="Edit profile"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          id={`discharge-pt-${p.id}`}
                          onClick={() => onDeletePatient(p.id)}
                          className="p-1 text-slate-400 hover:text-red-500 rounded-md transition hover:bg-slate-50 cursor-pointer"
                          title="Discharge patient"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Vitals Summary Table */}
                  <div className="grid grid-cols-2 gap-2 p-2 bg-slate-50 rounded-lg text-slate-600 text-xs font-sans my-3" id={`patient-vitals-box-${p.id}`}>
                    <div>
                      <span className="text-[10px] text-slate-500">Gender / Age</span>
                      <p className="font-medium">{p.gender}, {p.age} yrs</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500">Weight / Height</span>
                      <p className="font-medium">{p.weight} kg, {p.height} cm</p>
                    </div>
                  </div>

                  {/* Clinical Conditions */}
                  {p.medicalConditions.length > 0 && (
                    <div className="mb-2" id={`patient-conds-box-${p.id}`}>
                      <span className="text-[10px] text-slate-500 uppercase tracking-wide font-semibold block mb-1">Medical Conditions</span>
                      <div className="flex flex-wrap gap-1" id={`patient-cond-tags-${p.id}`}>
                        {p.medicalConditions.map((cond, i) => (
                          <span key={i} className="text-[10px] font-medium bg-amber-50 text-amber-700 border border-amber-100 rounded-md px-1.5 py-0.5">
                            {cond}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Patient Allergies flagged red */}
                  {p.allergies.length > 0 && (
                    <div className="mb-2" id={`patient-allergen-box-${p.id}`}>
                      <span className="text-[10px] text-slate-500 uppercase tracking-wide font-bold block mb-1 flex items-center gap-0.5 text-red-500">
                        <AlertOctagon className="w-3 h-3 shrink-0" /> Strict Allergies
                      </span>
                      <div className="flex flex-wrap gap-1" id={`patient-allergy-tags-${p.id}`}>
                        {p.allergies.map((all, i) => (
                          <span key={i} className="text-[10px] bg-red-50 text-red-700 font-semibold border border-red-100 rounded-md px-1.5 py-0.5">
                            {all}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Target Nutrition Metrics display */}
                <div className="border-t border-slate-100 bg-emerald-50/15 p-4 flex items-center justify-between text-xs animate-none" id={`patient-footer-${p.id}`}>
                  <div className="flex items-center gap-3" id={`pt-kcal-stat-${p.id}`}>
                    
                    {/* SVG circular progress ring */}
                    <div className="relative flex items-center justify-center w-9 h-9 shrink-0 select-none" title={`${consumedCalories} / ${p.targetCalories} kcal consumed (${percentOfGoal}%)`}>
                      <svg className="w-9 h-9 -rotate-90">
                        <circle
                          cx="18"
                          cy="18"
                          r={radius}
                          className="stroke-slate-200 fill-none"
                          strokeWidth="2.5"
                        />
                        <circle
                          cx="18"
                          cy="18"
                          r={radius}
                          className="stroke-emerald-600 fill-none transition-all duration-300"
                          strokeWidth="2.5"
                          strokeDasharray={circumference}
                          strokeDashoffset={strokeDashoffset}
                          strokeLinecap="round"
                        />
                      </svg>
                      <span className="absolute text-[8px] font-mono font-bold text-emerald-800">
                        {percentOfGoal}%
                      </span>
                    </div>

                    <div>
                      <span className="text-[9px] text-slate-500 block leading-none">Daily Calorie Target</span>
                      <p className="font-mono font-bold text-emerald-700 text-xs mt-0.5 leading-none">{p.targetCalories} kcal</p>
                      {approvedPlan && (
                        <span className="text-[8px] text-slate-400 block mt-0.5 leading-none font-medium">
                          Served: {consumedCalories} kcal
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right flex gap-3 text-[10px] font-semibold text-slate-600" id={`pt-macro-stat-${p.id}`}>
                    <div>
                      <span className="text-slate-500 uppercase block text-[8px]">PRO</span>
                      <span>{p.macronutrients.protein}g</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase block text-[8px]">CARB</span>
                      <span>{p.macronutrients.carbs}g</span>
                    </div>
                    <div>
                      <span className="text-slate-500 uppercase block text-[8px]">FAT</span>
                      <span>{p.macronutrients.fat}g</span>
                    </div>
                  </div>
                </div>

              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
