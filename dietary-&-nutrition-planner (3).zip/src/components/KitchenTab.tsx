/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { KitchenOrder, User } from '../types.js';
import { ChefHat, AlertOctagon, CheckSquare, Clock, ShieldAlert, CheckCircle2, UserCheck, Flame, Filter, UtensilsCrossed } from 'lucide-react';

interface KitchenProps {
  orders: KitchenOrder[];
  onUpdateOrderStatus: (orderId: string, status: KitchenOrder['status'], assignedStaff?: string) => Promise<void>;
  currentUser: User;
}

export default function KitchenTab({ orders, onUpdateOrderStatus, currentUser }: KitchenProps) {
  const [statusFilter, setStatusFilter] = useState('Active');
  const [mealTimeFilter, setMealTimeFilter] = useState('All');

  const filteredOrders = orders.filter((o) => {
    const matchesStatus = statusFilter === 'All' || 
                          (statusFilter === 'Active' && ['Received', 'Preparing', 'Ready'].includes(o.status)) ||
                          o.status === statusFilter;
    const matchesMeal = mealTimeFilter === 'All' || o.mealTime === mealTimeFilter;
    return matchesStatus && matchesMeal;
  });

  const handleStatusShift = async (orderId: string, currentStatus: KitchenOrder['status']) => {
    let nextStatus: KitchenOrder['status'] = 'Received';
    if (currentStatus === 'Received') nextStatus = 'Preparing';
    else if (currentStatus === 'Preparing') nextStatus = 'Ready';
    else if (currentStatus === 'Ready') nextStatus = 'Delivered';

    await onUpdateOrderStatus(orderId, nextStatus, currentUser.name);
  };

  const handleCancelOrder = async (orderId: string) => {
    await onUpdateOrderStatus(orderId, 'Cancelled', currentUser.name);
  };

  return (
    <div className="space-y-6" id="kitchen-tab-root">
      
      {/* Top Controls & Filter headers */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-4 rounded-xl border border-slate-100 shadow-xs" id="kitchen-controls-header">
        
        <div className="flex flex-wrap items-center gap-3" id="kitchen-filters">
          <div className="flex items-center gap-1.5 text-slate-700 text-xs font-semibold mr-2" id="filter-label">
            <Filter className="w-4 h-4 text-slate-400" /> Filter Kitchen Line:
          </div>

          <div className="inline-flex rounded-lg p-0.5 bg-slate-100 text-xs text-slate-600" id="status-filter-toggle">
            {['Active', 'Received', 'Preparing', 'Ready', 'Delivered', 'All'].map((s) => (
              <button
                key={s}
                id={`kitchen-filter-status-${s}`}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1.5 rounded-md font-sans font-medium transition cursor-pointer ${
                  statusFilter === s ? 'bg-white text-slate-800 font-bold shadow-xs' : 'hover:text-slate-900'
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          <select
            id="meal-time-filter"
            className="text-xs border border-slate-200 rounded-lg px-3 py-1.5 bg-white focus:outline-none"
            value={mealTimeFilter}
            onChange={(e) => setMealTimeFilter(e.target.value)}
          >
            <option value="All">All Meal Times</option>
            <option value="Breakfast">Breakfast</option>
            <option value="Lunch">Lunch</option>
            <option value="Dinner">Dinner</option>
            <option value="Snack">Snacks</option>
          </select>
        </div>

      </div>

      {/* Orders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="kitchen-orders-grid">
        {filteredOrders.length === 0 ? (
          <div className="col-span-full border border-dashed border-slate-200 rounded-xl p-16 text-center text-slate-400" id="empty-kitchen-state">
            <ChefHat className="w-12 h-12 stroke-1 mx-auto mb-2 text-slate-300 animate-pulse" />
            <p className="text-sm font-semibold">Hospital Kitchen Line is Empty</p>
            <p className="text-xs text-slate-500 mt-1">Once doctor approves a dietitian\'s meal plan, kitchen orders automatically synchronize here.</p>
          </div>
        ) : (
          filteredOrders.map((o) => {
            const hasAllergies = o.specialInstructions.toLowerCase().includes('allerg') || o.allergens.length > 0;
            
            return (
              <div
                key={o.id}
                id={`kitchen-card-${o.id}`}
                className={`bg-white border rounded-xl shadow-xs overflow-hidden flex flex-col justify-between transition hover:shadow-sm ${
                  o.status === 'Ready' ? 'border-emerald-200' :
                  o.status === 'Preparing' ? 'border-emerald-200' :
                  hasAllergies ? 'border-rose-100' : 'border-slate-100'
                }`}
              >
                
                {/* Header detail */}
                <div className="p-4" id={`kitchen-header-${o.id}`}>
                  <div className="flex justify-between items-start" id={`kitchen-meta-${o.id}`}>
                    <div>
                      <span className="font-mono text-[9px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded font-bold">{o.id}</span>
                      <span className="ml-1.5 font-sans font-bold text-emerald-700 text-[10px] uppercase font-mono">{o.mealTime}</span>
                      <h4 className="font-sans font-bold text-slate-800 text-sm mt-1">{o.mealTitle}</h4>
                      <p className="text-slate-500 text-[11px] font-sans">Patient: <strong className="text-slate-700">{o.patientName}</strong> (Ward {o.ward} • Room {o.roomNumber})</p>
                    </div>
                    
                    {/* Status badge */}
                    <div className="text-right" id={`kitchen-badge-${o.id}`}>
                      <span className={`text-[10px] font-bold px-2 py-1 rounded-full border ${
                        o.status === 'Received' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                        o.status === 'Preparing' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                        o.status === 'Ready' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                        o.status === 'Delivered' ? 'bg-slate-100 text-slate-600 border-slate-200' :
                        'bg-red-50 text-red-800 border-red-200'
                      }`}>
                        {o.status}
                      </span>
                      {o.assignedStaff && (
                        <span className="text-[9px] text-slate-400 block font-mono italic mt-1.5">Assigned: {o.assignedStaff}</span>
                      )}
                    </div>
                  </div>

                  {/* Ingredients */}
                  <div className="my-3 p-2.5 bg-slate-50 rounded text-xs gap-1" id={`kitchen-ingredients-${o.id}`}>
                    <strong className="text-[10px] text-slate-600 block mb-0.5 font-mono">Hospital Ingredient Recipe:</strong>
                    <p className="text-slate-600 leading-snug">{o.ingredients.join(', ')}</p>
                  </div>

                  {/* Sanitizing / Critical Allergy Alerts */}
                  {hasAllergies && (
                    <div className="p-2.5 bg-rose-50 border border-rose-100 text-[11px] text-rose-800 rounded flex items-start gap-1.5 mb-2" id={`kitchen-allergy-${o.id}`}>
                      <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5 animate-pulse" />
                      <div>
                        <strong className="font-bold">Strict Allergen Sanitization check:</strong>
                        <p className="opacity-90 leading-tight">{o.specialInstructions}</p>
                      </div>
                    </div>
                  )}

                  {!hasAllergies && (
                    <div className="p-2 bg-emerald-50/20 border border-emerald-100/50 text-[10px] text-slate-600 rounded flex items-center gap-1" id={`kitchen-safe-${o.id}`}>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                      No registered ingredients conflict with patient allergies.
                    </div>
                  )}

                </div>

                {/* Status action layout */}
                <div className="border-t border-slate-100 bg-slate-50/50 p-2.5 flex items-center justify-between" id={`kitchen-actions-${o.id}`}>
                  <span className="text-[9px] font-mono text-slate-400">Pushed: {new Date(o.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  
                  <div className="flex gap-1.5" id={`kitchen-act-btns-${o.id}`}>
                    {['Received', 'Preparing', 'Ready'].includes(o.status) && (
                      <button
                        id={`shift-status-${o.id}`}
                        onClick={() => handleStatusShift(o.id, o.status)}
                        className={`font-semibold text-[10px] px-3 py-1.5 rounded shadow-xs cursor-pointer flex items-center gap-0.5 transition ${
                          o.status === 'Received' ? 'bg-amber-600 hover:bg-amber-700 text-white' :
                          o.status === 'Preparing' ? 'bg-emerald-600 hover:bg-emerald-700 text-white' :
                          'bg-emerald-600 hover:bg-emerald-700 text-white'
                        }`}
                      >
                        {o.status === 'Received' ? <Flame className="w-3 h-3 text-white" /> : <Clock className="w-3 h-3" />}
                        {o.status === 'Received' ? 'Begin Cooking' : o.status === 'Preparing' ? 'Set as Ready' : 'Mark Delivered'}
                      </button>
                    )}

                    {['Received', 'Preparing'].includes(o.status) && (
                      <button
                        id={`cancel-order-${o.id}`}
                        onClick={() => handleCancelOrder(o.id)}
                        className="p-1 px-2 border border-slate-200 hover:border-red-200 text-slate-500 hover:text-red-600 rounded text-[10px] transition cursor-pointer"
                      >
                        Cancel
                      </button>
                    )}

                    {o.status === 'Delivered' && (
                      <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-0.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Served Successfully
                      </span>
                    )}

                    {o.status === 'Cancelled' && (
                      <span className="text-[10px] text-red-700 font-semibold italic">
                        Cancelled Staff Order
                      </span>
                    )}
                  </div>
                </div>

              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
