/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Patient, MealPlan, KitchenOrder } from '../types.js';
import { Download, ScrollText, CheckCircle2, ChevronRight, Sparkles, Filter, Database, FileSpreadsheet, Percent, AlertOctagon, RefreshCw } from 'lucide-react';

interface ReportsProps {
  patients: Patient[];
  mealPlans: MealPlan[];
  orders: KitchenOrder[];
}

export default function ReportsTab({ patients, mealPlans, orders }: ReportsProps) {
  const [reportType, setReportType] = useState<'Patients' | 'MealPlans' | 'KitchenOrders'>('Patients');

  // Calculations
  const totalPatients = patients.length;
  const activeMealPlans = mealPlans.length;
  const totalKitchenOrders = orders.length;
  const deliveredOrders = orders.filter(o => o.status === 'Delivered').length;
  const fulfillmentRate = totalKitchenOrders > 0 ? Math.round((deliveredOrders / totalKitchenOrders) * 100) : 100;
  
  // Calculate simulated allergy prevention audits
  const flaggedAllergyPlans = mealPlans.filter(mp => !mp.allergyCheckPassed).length;
  const safePlans = mealPlans.filter(mp => mp.allergyCheckPassed).length;

  const handleDownloadCSV = () => {
    let csvContent = "";
    let fileName = "";

    if (reportType === 'Patients') {
      fileName = "hospital_inpatient_directory.csv";
      csvContent = "Patient ID,Name,Age,Gender,Weight (kg),Height (cm),Ward,Room,Daily Target Calories,Protein (g),Carbs (g),Fat (g),Allergies,Medical Conditions,Admission Date\n";
      patients.forEach(p => {
        csvContent += `"${p.id}","${p.name}",${p.age},"${p.gender}",${p.weight},${p.height},"${p.ward}","${p.roomNumber}",${p.targetCalories},${p.macronutrients.protein},${p.macronutrients.carbs},${p.macronutrients.fat},"${p.allergies.join('; ')}","${p.medicalConditions.join('; ')}","${p.admissionDate}"\n`;
      });
    } else if (reportType === 'MealPlans') {
      fileName = "patient_dietary_meal_plans.csv";
      csvContent = "Plan ID,Patient ID,Patient Name,Total Calories,Protein (g),Carbs (g),Fat (g),Allergy Cleared,Workflow Sync,Approved By,Created Date,Diagnosis Rationale\n";
      mealPlans.forEach(mp => {
        csvContent += `"${mp.id}","${mp.patientId}","${mp.patientName}",${mp.totalCalories},${mp.totalProtein},${mp.totalCarbs},${mp.totalFat},"${mp.allergyCheckPassed}","${mp.status}","${mp.approvedBy || 'N/A'}","${mp.createdAt}","${mp.suitabilityRationale.replace(/"/g, '""')}"\n`;
      });
    } else {
      fileName = "culinary_kitchen_orders_audit.csv";
      csvContent = "Order ID,Patient Name,Meal Time,Meal Title,Room Number,Ward,Meal Date,Preparation Status,Assigned Culinary Staff,Log Date\n";
      orders.forEach(o => {
        csvContent += `"${o.id}","${o.patientName}","${o.mealTime}","${o.mealTitle}","${o.roomNumber}","${o.ward}","${o.mealDate}","${o.status}","${o.assignedStaff || 'Unassigned'}","${o.updatedAt}"\n`;
      });
    }

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", fileName);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="reports-tab-root">
      
      {/* Metrics Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" id="metrics-grid">
        
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex items-center justify-between" id="metric-patients">
          <div>
            <span className="text-[10px] text-slate-400 font-mono font-semibold uppercase block">Total Hospital Inpatients</span>
            <h2 className="text-3xl font-mono font-bold text-slate-800 leading-tight mt-1">{totalPatients}</h2>
            <p className="text-[10px] text-emerald-600 font-sans mt-1">✓ Fully registered in EMR</p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <Database className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex items-center justify-between" id="metric-plans">
          <div>
            <span className="text-[10px] text-slate-400 font-mono font-semibold uppercase block">Evaluated Diet Plans</span>
            <h2 className="text-3xl font-mono font-bold text-slate-800 leading-tight mt-1">{activeMealPlans}</h2>
            <p className="text-[10px] text-slate-500 font-sans mt-1">Matching patients vitals</p>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg">
            <ScrollText className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex items-center justify-between" id="metric-culinary">
          <div>
            <span className="text-[10px] text-slate-400 font-mono font-semibold uppercase block">Kitchen Orders Pushed</span>
            <h2 className="text-3xl font-mono font-bold text-slate-800 leading-tight mt-1">{totalKitchenOrders}</h2>
            <p className="text-[10px] text-emerald-600 font-sans mt-1">{deliveredOrders} served to beds</p>
          </div>
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
            <Percent className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex items-center justify-between" id="metric-fulfillment">
          <div>
            <span className="text-[10px] text-slate-400 font-mono font-semibold uppercase block">Fulfillment Performance</span>
            <h2 className="text-3xl font-mono font-bold text-slate-800 leading-tight mt-1">{fulfillmentRate}%</h2>
            <p className="text-[10px] text-emerald-600 font-sans mt-1">Excellent delivery compliance</p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* Visual compliance reports & audits */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="reports-main-layout">
        
        {/* Patient Calorie matching review list */}
        <div className="lg:col-span-7 bg-white p-6 rounded-xl border border-slate-100 shadow-xs space-y-4" id="calorie-compliance-panel">
          <div>
            <h3 className="font-sans font-bold text-base text-slate-800 tracking-tight leading-tight">Patient Energy Target Alignment Audit</h3>
            <p className="text-slate-500 text-xs mt-0.5">Compares daily calorie targets against computed meal plans in hospital database.</p>
          </div>

          <div className="space-y-4 max-h-[350px] overflow-y-auto pr-1" id="caloric-comparison-list">
            {patients.map((p) => {
              const matchedPlan = mealPlans.find(mp => mp.patientId === p.id && mp.status === 'Approved');
              const delta = matchedPlan ? Math.abs(matchedPlan.totalCalories - p.targetCalories) : null;
              const matchesKcal = delta !== null && delta <= p.targetCalories * 0.15; // Within 15% safety window

              return (
                <div key={p.id} className="p-3.5 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between gap-4 text-xs" id={`patient-cal-card-${p.id}`}>
                  <div>
                    <h4 className="font-bold text-slate-800 tracking-tight">{p.name}</h4>
                    <p className="text-slate-500 text-[10px] font-mono">{p.id} • Ward: {p.ward}</p>
                    <div className="flex gap-2 text-[10px] mt-1.5 font-semibold text-slate-600" id="macros-metric-p">
                      <span>Pro: {p.macronutrients.protein}g</span>
                      <span>Carb: {p.macronutrients.carbs}g</span>
                      <span>Fat: {p.macronutrients.fat}g</span>
                    </div>
                  </div>

                  <div className="text-right" id="target-matching-comparison">
                    <span className="text-[10px] text-slate-400 block font-mono">BMR target: {p.targetCalories} kcal</span>
                    {matchedPlan ? (
                      <div className="mt-1" id="comparison-resolved">
                        <strong className="text-emerald-700 font-mono font-bold">{matchedPlan.totalCalories} kcal served</strong>
                        <span className={`block text-[10px] font-bold ${matchesKcal ? 'text-emerald-600' : 'text-amber-600'}`}>
                          {matchesKcal ? '✓ Clinical target matched' : '⚠ Requires portion adjustment'}
                        </span>
                      </div>
                    ) : (
                      <div className="mt-1 text-slate-400 italic text-[10px]" id="comparison-empty">
                        No active authorized diet
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Export manager & File Generator */}
        <div className="lg:col-span-5 bg-white p-6 rounded-xl border border-slate-100 shadow-xs flex flex-col justify-between" id="export-selector-panel">
          <div className="space-y-4" id="file-export-content">
            <div>
              <h3 className="font-sans font-bold text-base text-slate-800 tracking-tight leading-tight">Regulatory Hospital Export Manager</h3>
              <p className="text-slate-500 text-xs mt-0.5">Extract EMR, clinical meal, culinary telemetry for regulatory compliance.</p>
            </div>

            {/* Selector list */}
            <div className="space-y-2.5" id="report-type-selectors">
              <button
                id="select-opt-patients"
                onClick={() => setReportType('Patients')}
                className={`w-full p-3.5 rounded-lg border text-left flex items-center justify-between text-xs transition cursor-pointer ${
                  reportType === 'Patients' ? 'bg-emerald-50 text-emerald-800 border-emerald-200 font-semibold' : 'bg-slate-50/50 hover:bg-slate-50 text-slate-600 border-slate-100'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-slate-500" />
                  <div>
                    <p className="font-bold">Inpatient Directory Telemetry</p>
                    <p className="text-[10px] opacity-80">EMR patient ages, medical histories, allergies.</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                id="select-opt-mealplans"
                onClick={() => setReportType('MealPlans')}
                className={`w-full p-3.5 rounded-lg border text-left flex items-center justify-between text-xs transition cursor-pointer ${
                  reportType === 'MealPlans' ? 'bg-emerald-50 text-emerald-800 border-emerald-200 font-semibold' : 'bg-slate-50/50 hover:bg-slate-50 text-slate-600 border-slate-100'
                }`}
              >
                <div className="flex items-center gap-2">
                  <ScrollText className="w-4 h-4 text-slate-500" />
                  <div>
                    <p className="font-bold">Clinical Meal Plans Log</p>
                    <p className="text-[10px] opacity-80">Nutritional values, dietitian notes, doctor approvals.</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                id="select-opt-kitchenorders"
                onClick={() => setReportType('KitchenOrders')}
                className={`w-full p-3.5 rounded-lg border text-left flex items-center justify-between text-xs transition cursor-pointer ${
                  reportType === 'KitchenOrders' ? 'bg-emerald-50 text-emerald-800 border-emerald-200 font-semibold' : 'bg-slate-50/50 hover:bg-slate-50 text-slate-600 border-slate-100'
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-slate-500" />
                  <div>
                    <p className="font-bold">Culinary Kitchen Audit History</p>
                    <p className="text-[10px] opacity-80">Cooking logs, preparation times, delivered meals.</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="mt-8" id="download-actions-card">
            <button
              id="csv-download-trigger"
              onClick={handleDownloadCSV}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-3 rounded-lg shadow-sm hover:shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Download className="w-4 h-4" /> Download Selected CSV Report
            </button>
            <p className="text-center font-mono text-[9px] text-slate-400 mt-2">Outputs strict standards-compliant RFC 4180 CSV formats.</p>
          </div>
        </div>

      </div>

    </div>
  );
}
