/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { NotificationAlert } from '../types.js';
import { Bell, Flame, Check, Stethoscope, UserCheck, Inbox, ShieldAlert, Sparkles, X } from 'lucide-react';

interface NotificationsProps {
  notifications: NotificationAlert[];
  onMarkRead: (notificationId: string) => Promise<void>;
  onMarkAllRead: () => Promise<void>;
  isOpen: boolean;
  onClose: () => void;
}

export default function NotificationsPanel({ notifications, onMarkRead, onMarkAllRead, isOpen, onClose }: NotificationsProps) {
  if (!isOpen) return null;

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="absolute right-0 top-12 mt-2 w-80 sm:w-96 bg-white border border-slate-100 rounded-xl shadow-xl z-50 overflow-hidden" id="notifications-dropdown">
      
      {/* Header controls */}
      <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs" id="notification-header">
        <div className="flex items-center gap-1.5 font-bold text-slate-800" id="notification-unread-title">
          <Bell className="w-4 h-4 text-emerald-600" />
          <span>Inpatient Telemetry Logs ({unreadCount} unread)</span>
        </div>
        
        <div className="flex items-center gap-2" id="notification-header-actions">
          {unreadCount > 0 && (
            <button
              id="mark-all-read-btn"
              onClick={onMarkAllRead}
              className="text-emerald-600 hover:text-emerald-800 font-semibold cursor-pointer"
            >
              Clear unread
            </button>
          )}
          <button
            id="close-notifications-btn"
            onClick={onClose}
            className="p-1 hover:bg-slate-200 text-slate-500 rounded-full transition cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Logger alerts list */}
      <div className="max-h-[350px] overflow-y-auto divide-y divide-slate-100 text-slate-600 text-xs" id="notifications-list">
        {notifications.length === 0 ? (
          <div className="p-8 text-center text-slate-400" id="empty-notifications">
            <Inbox className="w-8 h-8 stroke-1 mx-auto mb-1.5 text-slate-300" />
            <p>No telemetry logs recorded today.</p>
          </div>
        ) : (
          notifications.map((n) => {
            return (
              <div
                key={n.id}
                id={`notification-item-${n.id}`}
                onClick={() => !n.read && onMarkRead(n.id)}
                className={`p-3 flex items-start gap-3 transition cursor-pointer hover:bg-slate-50/50 ${!n.read ? 'bg-emerald-50/10 font-semibold' : ''}`}
              >
                {/* Icon mapping */}
                <div className="shrink-0 mt-0.5" id={`notif-icon-col-${n.id}`}>
                  {n.type === 'allergy' ? (
                    <div className="p-1.5 bg-red-100 text-red-600 rounded">
                      <ShieldAlert className="w-3.5 h-3.5" />
                    </div>
                  ) : n.type === 'approval' ? (
                    <div className="p-1.5 bg-amber-100 text-amber-600 rounded">
                      <Stethoscope className="w-3.5 h-3.5" />
                    </div>
                  ) : (
                    <div className="p-1.5 bg-indigo-100 text-indigo-600 rounded">
                      <UserCheck className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 space-y-0.5" id={`notif-body-col-${n.id}`}>
                  <div className="flex justify-between items-baseline" id={`notif-title-row-${n.id}`}>
                    <h5 className="font-sans font-bold text-slate-800 tracking-tight text-[11px]">{n.title}</h5>
                    <span className="text-[9px] font-mono text-slate-400">
                      {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 leading-tight font-sans">{n.message}</p>
                </div>

                {/* Indicator dot */}
                {!n.read && (
                  <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full shrink-0 self-center" id={`notif-dot-${n.id}`}></div>
                )}
              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
