/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Patient } from '../types.js';

export interface CalculationInput {
  age: number;
  gender: 'Male' | 'Female';
  weight: number; // kg
  height: number; // cm
  activityLevel: 'Sedentary' | 'Light' | 'Moderate' | 'Active';
  stressFactor: number; // multiplier
}

export function calculateBMR(input: Omit<CalculationInput, 'activityLevel' | 'stressFactor'>): number {
  if (input.gender === 'Male') {
    return Math.round(10 * input.weight + 6.25 * input.height - 5 * input.age + 5);
  } else {
    return Math.round(10 * input.weight + 6.25 * input.height - 5 * input.age - 161);
  }
}

export function calculateDailyTargetCalories(input: CalculationInput): number {
  const bmr = calculateBMR(input);
  
  let activityMultiplier = 1.2;
  switch (input.activityLevel) {
    case 'Sedentary': activityMultiplier = 1.2; break;
    case 'Light': activityMultiplier = 1.375; break;
    case 'Moderate': activityMultiplier = 1.55; break;
    case 'Active': activityMultiplier = 1.725; break;
  }

  // Adjust calories = BMR * Activity * StressFactor
  return Math.round(bmr * activityMultiplier * input.stressFactor);
}

export function calculateMacronutrients(targetCalories: number, medicalConditions: string[]): {
  protein: number;
  carbs: number;
  fat: number;
} {
  // Balanced default distribution (Protein: 20%, Carbs: 50%, Fat: 30%)
  let proteinPct = 0.20;
  let carbsPct = 0.50;
  let fatPct = 0.30;

  const hasDiabetes = medicalConditions.some(c => 
    c.toLowerCase().includes('diabetes') || c.toLowerCase().includes('diabet')
  );
  const hasCKD = medicalConditions.some(c => 
    c.toLowerCase().includes('ckd') || c.toLowerCase().includes('renal') || c.toLowerCase().includes('kidney')
  );
  const hasCardio = medicalConditions.some(c => 
    c.toLowerCase().includes('hypertension') || c.toLowerCase().includes('cardio') || c.toLowerCase().includes('cholesterol')
  );

  if (hasDiabetes) {
    // Low carb, medium fat, high protein
    proteinPct = 0.25;
    carbsPct = 0.35;
    fatPct = 0.40;
  } else if (hasCKD) {
    // Strictly restrict protein to prevent renal load, high carb/healthy fats
    proteinPct = 0.10;
    carbsPct = 0.60;
    fatPct = 0.30;
  } else if (hasCardio) {
    // Low fat (lean), moderate carb, stable protein
    proteinPct = 0.22;
    carbsPct = 0.53;
    fatPct = 0.25;
  }

  // Calculate grams: Protein = 4 kcal/g, Carbs = 4 kcal/g, Fat = 9 kcal/g
  const proteinGrams = Math.round((targetCalories * proteinPct) / 4);
  const carbsGrams = Math.round((targetCalories * carbsPct) / 4);
  const fatGrams = Math.round((targetCalories * fatPct) / 9);

  return {
    protein: proteinGrams,
    carbs: carbsGrams,
    fat: fatGrams
  };
}
