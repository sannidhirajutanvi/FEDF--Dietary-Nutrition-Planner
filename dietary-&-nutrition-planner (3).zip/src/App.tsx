/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Patient, MealPlan, KitchenOrder, NotificationAlert, DiagnosticMetrics } from './types.js';
import LoginScreen from './components/LoginScreen.js';
import NotificationsPanel from './components/NotificationsPanel.js';
import PatientProfileTab from './components/PatientProfileTab.js';
import MealPlannerTab from './components/MealPlannerTab.js';
import KitchenTab from './components/KitchenTab.js';
import ReportsTab from './components/ReportsTab.js';
import PatientCompanionWorkspace from './components/PatientCompanionWorkspace.js';
import { Shield, Bell, LogOut, ChevronRight, CheckCircle, Database, Users, Sparkles, ChefHat, LayoutDashboard, Utensils, ScrollText, FileText, Loader2, AlertTriangle, Stethoscope, Search, Info, HelpCircle, Lightbulb, BookOpen, ArrowRight } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentTab, setCurrentTab] = useState<'Dashboard' | 'Patients' | 'Planner' | 'Kitchen' | 'Reports'>('Dashboard');
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [dashSearch, setDashSearch] = useState('');
  const [showGuide, setShowGuide] = useState(true);
  const [guideRole, setGuideRole] = useState<'Dietitian' | 'Doctor' | 'KitchenStaff' | 'Admin'>('Dietitian');

  // Synchronized States
  const [patients, setPatients] = useState<Patient[]>([]);
  const [mealPlans, setMealPlans] = useState<MealPlan[]>([]);
  const [kitchenOrders, setKitchenOrders] = useState<KitchenOrder[]>([]);
  const [notifications, setNotifications] = useState<NotificationAlert[]>([]);
  const [analytics, setAnalytics] = useState<DiagnosticMetrics>({
    totalPatients: 0,
    pendingApprovals: 0,
    activeDietsCount: 0,
    mealsInPreparation: 0,
    allergyTriggersPrevented: 0
  });

  const [loading, setLoading] = useState(true);

  // Sync state from server on app load and transitions
  useEffect(() => {
    fetchInitialData();
  }, [user]);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const [resPatients, resPlans, resOrders, resNotifs, resAnalytics] = await Promise.all([
        fetch('/api/patients').then(r => r.json()),
        fetch('/api/meal-plans').then(r => r.json()),
        fetch('/api/kitchen-orders').then(r => r.json()),
        fetch('/api/notifications').then(r => r.json()),
        fetch('/api/analytics').then(r => r.json())
      ]);

      setPatients(resPatients);
      setMealPlans(resPlans);
      setKitchenOrders(resOrders);
      setNotifications(resNotifs);
      setAnalytics(resAnalytics);
    } catch (e) {
      console.error('Failed to sync state from hospital server:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleLoginSuccess = (signedUser: User) => {
    setUser(signedUser);
    setCurrentTab('Dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentTab('Dashboard');
  };

  // CRUD Patient
  const handleAddPatient = async (patientData: Omit<Patient, 'id'>) => {
    try {
      await fetch('/api/patients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patientData)
      });
      await fetchInitialData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdatePatient = async (id: string, updates: Partial<Patient>) => {
    try {
      await fetch(`/api/patients/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      await fetchInitialData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeletePatient = async (id: string) => {
    try {
      await fetch(`/api/patients/${id}`, {
        method: 'DELETE'
      });
      await fetchInitialData();
    } catch (e) {
      console.error(e);
    }
  };

  // Meal Planner trigger calling server Gemini SDK API
  const handleGenerateMealPlan = async (pt: Patient): Promise<MealPlan> => {
    const res = await fetch('/api/meal-plan/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ patient: pt })
    });
    if (!res.ok) throw new Error('Clinical model generation failure');
    return res.json();
  };

  const handleSaveMealPlan = async (plan: MealPlan) => {
    try {
      await fetch('/api/meal-plans', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(plan)
      });
      await fetchInitialData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateMealPlanStatus = async (planId: string, status: 'Approved' | 'Rejected', doctorName: string) => {
    try {
      await fetch(`/api/meal-plans/${planId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, approvedBy: doctorName })
      });
      await fetchInitialData();
    } catch (e) {
      console.error(e);
    }
  };

  // Kitchen operations status transition
  const handleUpdateKitchenStatus = async (orderId: string, status: KitchenOrder['status'], assignedStaff?: string) => {
    try {
      await fetch(`/api/kitchen-orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, assignedStaff })
      });
      await fetchInitialData();
    } catch (e) {
      console.error(e);
    }
  };

  // Notifications operations
  const handleMarkNotificationRead = async (notifId: string) => {
    try {
      await fetch(`/api/notifications/${notifId}/read`, {
        method: 'POST'
      });
      await fetchInitialData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleMarkAllNotificationsRead = async () => {
    try {
      await fetch('/api/notifications/clear-all', {
        method: 'POST'
      });
      await fetchInitialData();
    } catch (e) {
      console.error(e);
    }
  };

  // Render Login screen if user not authenticated
  if (!user) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  // Bypasses the complex EMR administration panel for interactive patient logins
  if (user.role === 'Patient') {
    return (
      <PatientCompanionWorkspace
        user={user}
        patients={patients}
        mealPlans={mealPlans}
        kitchenOrders={kitchenOrders}
        onLogout={handleLogout}
        onSendFeedback={async (msg) => {
          try {
            await fetch('/api/notifications', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                title: 'Dietary Patient Input',
                message: msg,
                type: 'info',
                patientId: user.id,
                read: false,
                createdAt: new Date().toISOString()
              })
            });
            await fetchInitialData();
          } catch (e) {
            console.error(e);
          }
        }}
        onTriggerDietRequest={async (patientId, mealTime, request) => {
          try {
            await fetch('/api/notifications', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                title: 'Bedside Comfort Alert',
                message: `${user.name} requests: "${request}" for ${mealTime}`,
                type: 'update',
                patientId: patientId,
                read: false,
                createdAt: new Date().toISOString()
              })
            });
            await fetchInitialData();
          } catch (e) {
            console.error(e);
          }
        }}
      />
    );
  }

  const unreadNotifCount = notifications.filter(n => !n.read).length;

  return (
    <div className="flex h-screen w-full bg-slate-50 font-sans select-none text-slate-700 overflow-hidden" id="app-root">
      
      {/* Sidebar navigation matching design layout */}
      <aside className="w-64 bg-slate-900 flex flex-col shrink-0 text-slate-300" id="app-nav-rail">
        <div className="p-6 border-b border-slate-800 flex items-center gap-3" id="sidebar-logo">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center text-white font-bold tracking-tight">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-white font-bold text-lg leading-tight">NutriPlan<span className="text-emerald-400 font-bold">Pro</span></h1>
        </div>

        <nav className="flex-1 py-6 px-4 space-y-1" id="sidebar-nav">
          <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-500 px-3 py-1 font-mono mb-2">Operations Console</label>
          
          <button
            id="nav-to-Dashboard"
            onClick={() => setCurrentTab('Dashboard')}
            className={`w-full text-left px-4 py-3 rounded-lg text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
              currentTab === 'Dashboard' ? 'bg-slate-800 text-white shadow-sm font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 text-emerald-500" /> Comprehensive Dashboard
          </button>

          <button
            id="nav-to-Patients"
            onClick={() => setCurrentTab('Patients')}
            className={`w-full text-left px-4 py-3 rounded-lg text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
              currentTab === 'Patients' ? 'bg-slate-800 text-white shadow-sm font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Users className="w-4 h-4 text-emerald-500" /> Patient Profiles & Calculators
          </button>

          <button
            id="nav-to-Planner"
            onClick={() => setCurrentTab('Planner')}
            className={`w-full text-left px-4 py-3 rounded-lg text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
              currentTab === 'Planner' ? 'bg-slate-800 text-white shadow-sm font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <ScrollText className="w-4 h-4 text-emerald-500" /> AI Nutrient Planner
          </button>

          <button
            id="nav-to-Kitchen"
            onClick={() => setCurrentTab('Kitchen')}
            className={`w-full text-left px-4 py-3 rounded-lg text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
              currentTab === 'Kitchen' ? 'bg-slate-800 text-white shadow-sm font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <ChefHat className="w-4 h-4 text-emerald-500" /> Clinical Kitchen Queue
          </button>

          <button
            id="nav-to-Reports"
            onClick={() => setCurrentTab('Reports')}
            className={`w-full text-left px-4 py-3 rounded-lg text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
              currentTab === 'Reports' ? 'bg-slate-800 text-white shadow-sm font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-500" /> Reports & Diagnostics Log
          </button>
        </nav>

        {/* User profile clearance and details in sidebar */}
        <div className="p-4 border-t border-slate-800" id="staff-notes-drawer">
          <div className="p-3 bg-slate-800 rounded-lg flex items-center gap-3 text-left" id="staff-authorizations-indicator">
            <div className="shrink-0 w-8 h-8 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-xs" id="user-avatar-initials">
              {user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-bold text-white tracking-tight truncate">{user.name}</p>
              <span className="text-[10px] font-mono text-emerald-400 block truncate mt-0.5">{user.role} ({user.department})</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Container Area */}
      <main className="flex-1 flex flex-col overflow-hidden" id="app-main-view">
        
        {/* Top Header Section */}
        <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between shrink-0" id="app-header">
          <div className="flex items-center gap-4">
            <h2 className="text-sm font-semibold text-slate-800 tracking-wider font-sans">NutriPlanPro Administrative Console</h2>
          </div>

          <div className="flex items-center gap-6" id="header-user-panel">
            <div className="relative text-left" id="notifications-trigger-area">
              <button
                id="notifications-bell-btn"
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="p-2 hover:bg-slate-50 rounded-full text-slate-500 relative transition cursor-pointer"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white font-mono font-bold text-[9px] w-4 h-4 rounded-full flex items-center justify-center border-2 border-white animate-pulse">
                    {unreadNotifCount}
                  </span>
                )}
              </button>
              <NotificationsPanel
                notifications={notifications}
                onMarkRead={handleMarkNotificationRead}
                onMarkAllRead={handleMarkAllNotificationsRead}
                isOpen={isNotifOpen}
                onClose={() => setIsNotifOpen(false)}
              />
            </div>

            <div className="border-l border-slate-200 h-6 shrink-0" id="header-separator"></div>

            <button
              id="logout-btn"
              onClick={handleLogout}
              title="Sign out of hospital session"
              className="p-2 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-full transition cursor-pointer"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Dynamic Workspace Tab Content with Y-axis scrolling */}
        <div className="flex-1 p-8 space-y-6 overflow-y-auto" id="workspace-main-panel">
          
          {/* Global Loader state if syncing with server */}
          {loading && (
            <div className="flex flex-col items-center justify-center p-24 text-slate-400" id="global-sync-loading">
              <Loader2 className="w-10 h-10 animate-spin text-emerald-600 mb-2" />
              <p className="text-sm font-sans font-medium">Synchronizing medical data logs from EMR systems...</p>
            </div>
          )}

          {!loading && (
            <>
              {/* Tab 1: Comprehensive Dashboard */}
              {currentTab === 'Dashboard' && (
                <div className="space-y-6" id="dashboard-tab-root">
                  
                  {/* Banner / User welcome notification with Search Bar */}
                  <div className="bg-white border border-slate-100 rounded-xl p-5 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4" id="welcome-banner">
                    <div>
                      <div className="flex items-center gap-2 mb-1.5" id="banner-badges">
                        <span className="bg-emerald-100 text-emerald-800 text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider font-mono">
                          Care Compliance Mode
                        </span>
                        <button
                          type="button"
                          id="btn-toggle-guide"
                          onClick={() => setShowGuide(!showGuide)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 text-[10px] font-bold px-2.5 py-0.5 rounded-md transition cursor-pointer flex items-center gap-1 font-sans border border-slate-200"
                        >
                          <HelpCircle className="w-3 h-3 text-slate-500" />
                          {showGuide ? 'Hide Guide' : 'Show Guide'}
                        </button>
                      </div>
                      <h2 className="font-sans font-extrabold text-slate-800 text-xl tracking-tight leading-none">Patient Dietary Console Dashboard</h2>
                      <p className="text-slate-450 text-xs mt-1 font-sans">Monitoring inpatients allergy logs and medical menu synchronisation instantly.</p>
                    </div>
                    
                    {/* Compact Interactive Patient Filtering Search Box */}
                    <div className="relative w-full md:w-80 shrink-0" id="dash-top-search-wrapper">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none" id="dash-top-search-icon">
                        <Search className="h-4 w-4 text-slate-400" />
                      </div>
                      <input
                        type="text"
                        id="dash-search-box-input"
                        placeholder="Search patient, ward, or room..."
                        value={dashSearch}
                        onChange={(e) => setDashSearch(e.target.value)}
                        className="w-full text-xs pl-9 pr-8 py-2.5 bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-slate-700 placeholder-slate-400 border border-slate-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 rounded-xl focus:outline-none transition-all font-sans font-semibold shadow-xs"
                      />
                      {dashSearch && (
                        <button
                          type="button"
                          id="btn-clear-dash-search"
                          onClick={() => setDashSearch('')}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-450 hover:text-slate-600 transition cursor-pointer font-bold text-sm"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Interactive App Guide: Simplified, Clean, Step-by-Step Flowchart */}
                  {showGuide && (
                    <div className="bg-slate-900 rounded-2xl p-6 border border-slate-850 text-white relative overflow-hidden shadow-lg animate-none" id="interactive-user-guide">
                      <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-emerald-500/5 blur-2xl pointer-events-none"></div>
                      <div className="absolute -bottom-12 -right-12 w-48 h-48 rounded-full bg-teal-500/5 blur-2xl pointer-events-none"></div>

                      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 pb-4 border-b border-slate-850" id="guide-overview-header">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                            <Lightbulb className="w-5 h-5 text-emerald-400" />
                          </div>
                          <div>
                            <h3 className="font-sans font-bold text-sm text-white tracking-tight">Interactive NutriPlan Console Flow</h3>
                            <p className="text-[11px] text-slate-400">Master the entire patient clinical nutrition loop in 4 simplified stage trials.</p>
                          </div>
                        </div>
                        
                        {/* Selector for trial roles */}
                        <div className="flex items-center bg-slate-800/80 p-0.5 rounded-xl border border-slate-800 shrink-0" id="guide-role-selector">
                          <span className="text-[9px] font-mono font-bold text-slate-400 px-2.5 tracking-wider uppercase">Trial Guide:</span>
                          {(['Dietitian', 'Doctor', 'KitchenStaff', 'Admin'] as const).map((r) => (
                            <button
                              key={r}
                              id={`guide-role-btn-${r}`}
                              onClick={() => setGuideRole(r)}
                              className={`px-3 py-1 text-[10px] font-extrabold rounded-lg transition-all cursor-pointer ${
                                guideRole === r
                                  ? 'bg-emerald-500 text-slate-950 font-black'
                                  : 'text-slate-400 hover:text-white'
                              }`}
                            >
                              {r === 'KitchenStaff' ? 'Kitchen Chef' : r}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Timeline flow */}
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-5" id="guide-timeline-steps">
                        
                        <button
                          onClick={() => setCurrentTab('Patients')}
                          className="text-left group bg-slate-850/40 hover:bg-slate-850/85 p-4 rounded-xl border border-slate-800/80 hover:border-emerald-500/30 transition duration-200 cursor-pointer w-full relative"
                          id="step-1-pt"
                        >
                          <div className="absolute top-3 right-3 text-[9px] font-mono text-slate-600 font-bold group-hover:text-emerald-400 transition-colors">01 / STAGE</div>
                          <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-mono font-extrabold text-xs mb-3 group-hover:bg-emerald-500 group-hover:text-slate-950 transition">
                            <Users className="w-3.5 h-3.5" />
                          </div>
                          <h4 className="font-sans font-bold text-xs text-white group-hover:text-emerald-300 transition-colors flex items-center gap-1 group-hover:underline">
                            Admit Inpatients <ArrowRight className="w-3 h-3 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
                          </h4>
                          <p className="text-[10px] text-slate-450 mt-1 leading-relaxed">
                            Register age, medical conditions & allergens. Daily calorie target BMR formula runs automatically.
                          </p>
                        </button>

                        <button
                          onClick={() => setCurrentTab('Planner')}
                          className="text-left group bg-slate-850/40 hover:bg-slate-850/85 p-4 rounded-xl border border-slate-800/80 hover:border-emerald-500/30 transition duration-200 cursor-pointer w-full relative"
                          id="step-2-planner"
                        >
                          <div className="absolute top-3 right-3 text-[9px] font-mono text-slate-600 font-bold group-hover:text-emerald-400 transition-colors">02 / STAGE</div>
                          <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-mono font-bold text-xs mb-3 group-hover:bg-emerald-500 group-hover:text-slate-950 transition">
                            <Sparkles className="w-3.5 h-3.5" />
                          </div>
                          <h4 className="font-sans font-bold text-xs text-white group-hover:text-emerald-300 transition-colors flex items-center gap-1 group-hover:underline">
                            Generate AI Diet <ArrowRight className="w-3 h-3 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
                          </h4>
                          <p className="text-[10px] text-slate-450 mt-1 leading-relaxed">
                            Select patient, run clinical meal builder. Gemini scans allergies to formulate clean recipes.
                          </p>
                        </button>

                        <button
                          onClick={() => setCurrentTab('Planner')}
                          className="text-left group bg-slate-850/40 hover:bg-slate-850/85 p-4 rounded-xl border border-slate-800/80 hover:border-emerald-500/30 transition duration-200 cursor-pointer w-full relative"
                          id="step-3-auth"
                        >
                          <div className="absolute top-3 right-3 text-[9px] font-mono text-slate-600 font-bold group-hover:text-emerald-400 transition-colors">03 / STAGE</div>
                          <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-mono font-bold text-xs mb-3 group-hover:bg-emerald-500 group-hover:text-slate-950 transition">
                            <Stethoscope className="w-3.5 h-3.5" />
                          </div>
                          <h4 className="font-sans font-bold text-xs text-white group-hover:text-emerald-300 transition-colors flex items-center gap-1 group-hover:underline">
                            Physician Sign-off <ArrowRight className="w-3 h-3 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
                          </h4>
                          <p className="text-[10px] text-slate-450 mt-1 leading-relaxed">
                            Doctor credentials verify the food formulation so preparation and kitchen logs can be launched.
                          </p>
                        </button>

                        <button
                          onClick={() => setCurrentTab('Kitchen')}
                          className="text-left group bg-slate-850/40 hover:bg-slate-850/85 p-4 rounded-xl border border-slate-800/80 hover:border-emerald-500/30 transition duration-200 cursor-pointer w-full relative"
                          id="step-4-kitchen"
                        >
                          <div className="absolute top-3 right-3 text-[9px] font-mono text-slate-600 font-bold group-hover:text-emerald-400 transition-colors">04 / STAGE</div>
                          <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-mono font-bold text-xs mb-3 group-hover:bg-emerald-500 group-hover:text-slate-950 transition">
                            <ChefHat className="w-3.5 h-3.5" />
                          </div>
                          <h4 className="font-sans font-bold text-xs text-white group-hover:text-emerald-300 transition-colors flex items-center gap-1 group-hover:underline">
                            Kitchen Prep Queue <ArrowRight className="w-3 h-3 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
                          </h4>
                          <p className="text-[10px] text-slate-450 mt-1 leading-relaxed">
                            Approved meals sync automatically. Cooks prepare, finalize, and mark meals as hand-delivered.
                          </p>
                        </button>

                      </div>

                      {/* Display Selected Role Tips dynamically */}
                      <div className="mt-5 p-3.5 bg-slate-850 border border-slate-800 rounded-xl flex items-start gap-3" id="guide-contextual-tips">
                        <div className="p-1.5 bg-emerald-500/10 text-emerald-400 rounded-xl shrink-0">
                          <Info className="w-4 h-4 text-emerald-400" />
                        </div>
                        <div className="text-xs">
                          {guideRole === 'Dietitian' && (
                            <p className="text-slate-300 leading-normal">
                              👩‍⚕️ <strong className="text-emerald-400">Dietitian Mode:</strong> Go to <span className="font-bold cursor-pointer underline text-white" onClick={() => setCurrentTab('Patients')}>Patient Profiles</span> to add an inpatient, then navigate to <span className="font-bold cursor-pointer underline text-white" onClick={() => setCurrentTab('Planner')}>AI Nutrient Planner</span> to draft safety-inspected therapeutic diets using artificial intelligence.
                            </p>
                          )}
                          {guideRole === 'Doctor' && (
                            <p className="text-slate-300 leading-normal">
                              👨‍⚕️ <strong className="text-teal-350">Physician Mode:</strong> You can approve or reject nutrition drafts. Open the <span className="font-bold cursor-pointer underline text-white" onClick={() => setCurrentTab('Planner')}>AI Nutrient Planner</span> tab and search for pending plans to review with doctor credentials!
                            </p>
                          )}
                          {guideRole === 'KitchenStaff' && (
                            <p className="text-slate-300 leading-normal">
                              🍳 <strong className="text-amber-400">Kitchen Chef Mode:</strong> View real-time clinical recipes in the <span className="font-bold cursor-pointer underline text-white" onClick={() => setCurrentTab('Kitchen')}>Clinical Kitchen Queue</span>. Cooks can update meal status to "Preparing" or "Ready" when meals are served!
                            </p>
                          )}
                          {guideRole === 'Admin' && (
                            <p className="text-slate-300 leading-normal">
                              ⚙️ <strong className="text-emerald-400">Administrator Mode:</strong> Access automated compliance indicators, allergen threat metrics, meal completion timing stats, and download raw CSV data in <span className="font-bold cursor-pointer underline text-white" onClick={() => setCurrentTab('Reports')}>Reports & Diagnostics Log</span>!
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Top Stats Overview */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="overview-analytics-grid">
                    
                    <button
                      id="card-nav-patients"
                      onClick={() => setCurrentTab('Patients')}
                      className="bg-white p-4 rounded-xl border border-slate-100 hover:border-slate-200 shadow-xs hover:shadow-sm text-left flex items-start gap-4 transition cursor-pointer w-full"
                    >
                      <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-lg shrink-0">
                        <Users className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider font-semibold">Active Inpatients</span>
                        <h3 className="text-2xl font-mono font-bold text-slate-800 leading-none mt-1">{analytics.totalPatients}</h3>
                      </div>
                    </button>

                    <button
                      id="card-nav-approvals"
                      onClick={() => setCurrentTab('Planner')}
                      className="bg-white p-4 rounded-xl border border-slate-100 hover:border-slate-200 shadow-xs hover:shadow-sm text-left flex items-start gap-4 transition cursor-pointer w-full"
                    >
                      <div className="p-2.5 bg-amber-50 text-amber-600 rounded-lg shrink-0">
                        <ScrollText className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider font-semibold">Pending Approvals</span>
                        <h3 className="text-2xl font-mono font-bold text-slate-800 leading-none mt-1">{analytics.pendingApprovals}</h3>
                      </div>
                    </button>

                    <button
                      id="card-nav-kitchen"
                      onClick={() => setCurrentTab('Kitchen')}
                      className="bg-white p-4 rounded-xl border border-slate-100 hover:border-slate-200 shadow-xs hover:shadow-sm text-left flex items-start gap-4 transition cursor-pointer w-full"
                    >
                      <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-lg shrink-0">
                        <ChefHat className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider font-semibold">Active Cook Orders</span>
                        <h3 className="text-2xl font-mono font-bold text-slate-800 leading-none mt-1">{analytics.mealsInPreparation}</h3>
                      </div>
                    </button>

                    <button
                      id="card-nav-reports"
                      onClick={() => setCurrentTab('Reports')}
                      className="bg-white p-4 rounded-xl border border-slate-100 hover:border-slate-200 shadow-xs hover:shadow-sm text-left flex items-start gap-4 transition cursor-pointer w-full"
                    >
                      <div className="p-2.5 bg-red-50 text-red-600 rounded-lg shrink-0">
                        <Shield className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider font-semibold">Prevented Allergies</span>
                        <h3 className="text-2xl font-mono font-bold text-slate-800 leading-none mt-1">{analytics.allergyTriggersPrevented}</h3>
                      </div>
                    </button>

                  </div>

                  {/* Mid Segment: Patient summary status grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-mid-segment">
                    
                    {/* Active list table */}
                    <div className="lg:col-span-8 bg-white border border-slate-100 rounded-xl p-6 shadow-xs" id="pt-status-table-card">
                      <div className="flex justify-between items-center mb-4" id="table-head-row">
                        <div className="flex items-center gap-2" id="table-title-group">
                          <h3 className="font-sans font-bold text-slate-850 text-base tracking-tight flex items-center gap-1.5 leading-none">
                            <Database className="w-5 h-5 text-teal-600" /> Active Patient Diet Tracking
                          </h3>
                          {dashSearch && (
                            <span className="bg-emerald-55 bg-emerald-50 text-emerald-700 text-[10px] font-semibold px-2 py-0.5 rounded-full animate-none" id="search-active-pill">
                              Filtered matches
                            </span>
                          )}
                        </div>
                        <button
                          id="dash-expand-patients"
                          onClick={() => setCurrentTab('Patients')}
                          className="text-xs text-teal-600 hover:text-teal-800 font-bold transition flex items-center gap-0.5 cursor-pointer"
                        >
                          View all patient profiles <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="overflow-x-auto" id="table-container">
                        <table className="w-full text-left font-sans text-xs border-collapse text-slate-600" id="dash-pt-table">
                          <thead>
                            <tr className="border-b border-slate-100 text-slate-400 font-mono uppercase text-[9px]">
                              <th className="py-2 px-3">Patient</th>
                              <th className="py-2 px-3">Ward / Bed</th>
                              <th className="py-2 px-3">Allergy Risk</th>
                              <th className="py-2 px-3 font-mono">Calorie Target</th>
                              <th className="py-2 px-3">Sync State</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                            {(() => {
                              const filtered = patients.filter((p) => {
                                const q = dashSearch.toLowerCase().trim();
                                if (!q) return true;
                                return (
                                  p.name.toLowerCase().includes(q) ||
                                  p.ward.toLowerCase().includes(q) ||
                                  p.roomNumber.toLowerCase().includes(q)
                                );
                              });

                              if (filtered.length === 0) {
                                return (
                                  <tr>
                                    <td colSpan={5} className="text-center py-10 text-slate-400 italic font-sans">
                                      {patients.length === 0 
                                        ? "No inpatients registered in system." 
                                        : `No inpatients found matching "${dashSearch}"`}
                                    </td>
                                  </tr>
                                );
                              }

                              return filtered.map((p) => {
                                const activeMeal = mealPlans.find(mp => mp.patientId === p.id && mp.status === 'Approved');
                                return (
                                  <tr key={p.id} className="hover:bg-slate-50/50 transition bg-transparent" id={`dash-tr-${p.id}`}>
                                    <td className="py-2.5 px-3">
                                      <p className="font-sans font-bold text-slate-800 leading-snug">{p.name}</p>
                                      <span className="text-[10px] text-slate-400 font-mono">{p.id} ({p.gender}, {p.age}y)</span>
                                    </td>
                                    <td className="py-2.5 px-3">
                                      <p className="font-semibold text-slate-700">{p.ward}</p>
                                      <p className="text-[10px] text-slate-500">Room {p.roomNumber}</p>
                                    </td>
                                    <td className="py-2.5 px-3">
                                      {p.allergies.length > 0 ? (
                                        <span className="text-[10px] bg-red-50 text-red-700 font-bold px-2 py-0.5 border border-red-100 rounded-md">
                                          {p.allergies.join(', ')}
                                        </span>
                                      ) : (
                                        <span className="text-[10px] text-slate-400 italic">No allergies</span>
                                      )}
                                    </td>
                                    <td className="py-2.5 px-3 font-mono font-bold text-teal-700">
                                      {p.targetCalories} kcal
                                    </td>
                                    <td className="py-2.5 px-3">
                                      {activeMeal ? (
                                        <span className="text-emerald-700 font-semibold flex items-center gap-0.5" id={`sync-state-ok-${p.id}`}>
                                          <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" /> Synchronized
                                        </span>
                                      ) : (
                                        <span className="text-amber-700 font-semibold italic flex items-center gap-0.5" id={`sync-state-pending-${p.id}`}>
                                          <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" /> Pending Diet
                                        </span>
                                      )}
                                    </td>
                                  </tr>
                                );
                              });
                            })()}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Quick Notifications sidebar */}
                    <div className="lg:col-span-4 bg-white border border-slate-100 rounded-xl p-5 shadow-xs flex flex-col justify-between" id="dashboard-logger-panel">
                      <div id="logger-header">
                        <h3 className="font-sans font-bold text-slate-850 text-sm tracking-tight flex items-center gap-1.5 leading-none">
                          <Bell className="w-4.5 h-4.5 text-teal-600" /> Actionable Care Alerts
                        </h3>
                        <p className="text-[11px] text-slate-400 mt-1">Hospital notification logs of dietary preventions and chef updates.</p>
                      </div>

                      <div className="space-y-3 max-h-[200px] overflow-y-auto mt-4 pr-1" id="dash-notif-feed">
                        {notifications.slice(0, 4).map((n) => (
                          <div key={n.id} className="p-3 bg-slate-50 rounded-lg text-[11px] leading-relaxed relative border border-slate-100" id={`dash-notif-feed-item-${n.id}`}>
                            <div className="flex justify-between items-baseline mb-0.5" id={`notif-title-${n.id}`}>
                              <strong className="text-slate-700">{n.title}</strong>
                              <span className="text-[9px] font-mono text-slate-400">
                                {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-slate-500">{n.message}</p>
                          </div>
                        ))}
                      </div>

                      <button
                        id="mark-all-read-dash"
                        onClick={handleMarkAllNotificationsRead}
                        className="w-full text-center border border-slate-200 text-xs py-2 rounded-lg text-slate-600 hover:bg-slate-50 transition cursor-pointer mt-4"
                      >
                        Acknowledge All Alerts
                      </button>
                    </div>

                  </div>

                </div>
              )}

              {/* Tab 2: Patients directory */}
              {currentTab === 'Patients' && (
                <PatientProfileTab
                  patients={patients}
                  onAddPatient={handleAddPatient}
                  onUpdatePatient={handleUpdatePatient}
                  onDeletePatient={handleDeletePatient}
                  userRole={user.role}
                  mealPlans={mealPlans}
                  kitchenOrders={kitchenOrders}
                />
              )}

              {/* Tab 3: Planning queue with Gemini */}
              {currentTab === 'Planner' && (
                <MealPlannerTab
                  patients={patients}
                  mealPlans={mealPlans}
                  onGeneratePlan={handleGenerateMealPlan}
                  onSavePlan={handleSaveMealPlan}
                  onUpdatePlanStatus={handleUpdateMealPlanStatus}
                  currentUser={user}
                />
              )}

              {/* Tab 4: Kitchen orders log */}
              {currentTab === 'Kitchen' && (
                <KitchenTab
                  orders={kitchenOrders}
                  onUpdateOrderStatus={handleUpdateKitchenStatus}
                  currentUser={user}
                />
              )}

              {/* Tab 5: Analytics & export */}
              {currentTab === 'Reports' && (
                <ReportsTab
                  patients={patients}
                  mealPlans={mealPlans}
                  orders={kitchenOrders}
                />
              )}
            </>
          )}

        </div>

      </main>

    </div>
  );
}
